package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomePatient extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_patient);
        TextView welcomeMessage = findViewById(R.id.welcomeMessage);
        String role = getIntent().getStringExtra("role");
        welcomeMessage.setText("Welcome Patient! You are now logged in.");
    }

    public void onNextClick(View view) {
        Intent intent = new Intent(WelcomePatient.this, MenuPatient.class);
        String email = getIntent().getStringExtra("email");
        String firstName = getIntent().getStringExtra("firstName");
        String lastName = getIntent().getStringExtra("lastName");
        intent.putExtra("email", email);
        intent.putExtra("firstName", firstName);
        intent.putExtra("lastName", lastName);
        startActivity(intent);
    }
    public void onLogoutClick(View view) {
        Intent intent = new Intent(WelcomePatient.this, RoleSelectionActivity.class);
        startActivity(intent);
    }

}
