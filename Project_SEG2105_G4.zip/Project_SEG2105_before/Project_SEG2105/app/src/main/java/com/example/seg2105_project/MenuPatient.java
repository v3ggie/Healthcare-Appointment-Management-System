package com.example.seg2105_project;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MenuPatient extends AppCompatActivity {

    private TextView welcomeMessage;
    private String address;
    private String phone;
    private String firstName;
    private String lastName;
    private String healthCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_patient);

        welcomeMessage = findViewById(R.id.title);

        String email = getIntent().getStringExtra("email");
        // Check if the user is logged in
        retrieveHealthCard(email);
    }

    private void retrieveHealthCard(String email) {
        // Retrieve the patient's details from the database
        DatabaseReference patientsRef = FirebaseDatabase.getInstance().getReference("accepted").child("acceptedPatients");
        patientsRef.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Patient data found, update the welcome message
                    DataSnapshot patientSnapshot = dataSnapshot.getChildren().iterator().next();
                    firstName = patientSnapshot.child("firstName").getValue(String.class);
                    lastName = patientSnapshot.child("lastName").getValue(String.class);
                    address = patientSnapshot.child("address").getValue(String.class);
                    phone = patientSnapshot.child("phone").getValue(String.class);
                    healthCard = patientSnapshot.child("healthCard").getValue(String.class);
                } else {
                    // If the data doesn't exist, log a message for debugging
                    Log.d("MenuPatient", "Data does not exist.");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle database error
                Log.e("MenuPatient", "Error reading data: " + databaseError.getMessage());
            }
        });
    }

    public void onBookClick(View view) {
        Intent intent = new Intent(MenuPatient.this, MenuBookAppointment.class);
        String firstName = getIntent().getStringExtra("firstName");
        String lastName = getIntent().getStringExtra("lastName");
        String email = getIntent().getStringExtra("email");
        intent.putExtra("healthCard", healthCard);
        intent.putExtra("firstName", firstName);
        intent.putExtra("lastName", lastName);
        intent.putExtra("email", email);
        intent.putExtra("address",address);
        intent.putExtra("phone",phone);
        startActivity(intent);
    }

    public void onViewClick(View view) {
        Intent intent = new Intent(MenuPatient.this, MenuAppointments.class);
        intent.putExtra("healthCard", healthCard);
        startActivity(intent);
    }

    public void onViewPastClick(View view) {
        Intent intent = new Intent(MenuPatient.this, MenuPastAppointments.class);
        intent.putExtra("healthCard", healthCard);
        startActivity(intent);
    }

    public void onLogoutClick(View view) {
        Intent intent = new Intent(MenuPatient.this, RoleSelectionActivity.class);
        startActivity(intent);
    }
}
