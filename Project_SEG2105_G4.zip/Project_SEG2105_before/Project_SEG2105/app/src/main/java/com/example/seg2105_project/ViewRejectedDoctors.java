package com.example.seg2105_project;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class ViewRejectedDoctors extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_rejected_doctors);
        LinearLayout containerLayout = findViewById(R.id.containerP);

        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("rejected").child("rejectedDoctors");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot doctorSnapshot : dataSnapshot.getChildren()) {
                        String firstName = doctorSnapshot.child("firstName").getValue(String.class);
                        String lastName = doctorSnapshot.child("lastName").getValue(String.class);
                        String email = doctorSnapshot.child("email").getValue(String.class);
                        String phone = doctorSnapshot.child("phone").getValue(String.class);
                        String status = doctorSnapshot.child("status").getValue(String.class);

                        if (firstName != null && lastName != null && email != null && phone != null && status != null) {
                            LinearLayout patientLayout = new LinearLayout(ViewRejectedDoctors.this);
                            patientLayout.setOrientation(LinearLayout.VERTICAL);  // Change to VERTICAL
                            TextView textView = new TextView(ViewRejectedDoctors.this);
                            textView.setText(String.format("Name: %s\nEmail: %s\nPhone: %s\nStatus: %s",
                                    firstName, lastName, email, phone, status));
                            textView.setTextColor(getResources().getColor(android.R.color.white));
                            textView.setBackgroundResource(R.drawable.textview_background);
                            LinearLayout.LayoutParams textLayoutParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT
                            );
                            textView.setLayoutParams(textLayoutParams);
                            int paddingValueInDp = 14;
                            int paddingValueInPixels = (int) (paddingValueInDp * getResources().getDisplayMetrics().density);
                            textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);
                            Button acceptButton = new Button(ViewRejectedDoctors.this);
                            acceptButton.setText("Accept");
                            Button rejectButton = new Button(ViewRejectedDoctors.this);
                            rejectButton.setText("Reject");
                            acceptButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    acceptDoctor(doctorSnapshot);
                                    containerLayout.removeView(patientLayout);
                                }
                            });
                            patientLayout.addView(textView);
                            patientLayout.addView(acceptButton);
                            containerLayout.addView(patientLayout);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void acceptDoctor(DataSnapshot doctorSnapshot) {
        try {
            String employeeNumber = doctorSnapshot.child("employeeNumber").getValue(String.class);

            Map<String, Object> acceptedDoctor = new HashMap<>();
            acceptedDoctor.put("email", doctorSnapshot.child("email").getValue(String.class));
            acceptedDoctor.put("firstName", doctorSnapshot.child("firstName").getValue(String.class));
            acceptedDoctor.put("lastName", doctorSnapshot.child("lastName").getValue(String.class));
            acceptedDoctor.put("address", doctorSnapshot.child("address").getValue(String.class));
            acceptedDoctor.put("phone", doctorSnapshot.child("phone").getValue(String.class));
            acceptedDoctor.put("employeeNumber",employeeNumber);
            acceptedDoctor.put("password", doctorSnapshot.child("password").getValue(String.class));
            acceptedDoctor.put("status", "accepted"); // Set status to "accepted"

            DatabaseReference doctorRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("doctorRegRequests")
                    .child(employeeNumber);
            doctorRegRequestsRef.removeValue();

            DatabaseReference acceptedPatientsRef = FirebaseDatabase.getInstance()
                    .getReference("accepted")
                    .child("acceptedDoctors")
                    .child(employeeNumber);
            acceptedPatientsRef.setValue(acceptedDoctor);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onClickBack(View view) {
        Intent intent = new Intent(this, MenuAdminRejectedSelection.class);
        startActivity(intent);
    }
}
