package com.example.seg2105_project;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.checkerframework.checker.units.qual.C;
import org.checkerframework.checker.units.qual.Time;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

public class MenuBookAppointment extends AppCompatActivity{

    private String timeEditText;
    private Calendar timeCalendar;
    private CalendarView calendar;
    private TimePicker timePicker;
    private String format;
    private TextView date;
    private String appointmentDay;
    private EditText doctorNameEditText;
    private Button bookAppointmentButton;
    private String specialtySelected;
    private String doctorSelected;
    private DatabaseReference databaseReference;
    private List<Doctor> doctors;
    private String namePatient;
    private String idPatient;
    private String idAppointment;
    private LinearLayout specialtySelect;
    private ArrayList<String> specialties;
    private LinearLayout doctorSelect;
    private ArrayList<String> doctorChoices;
    DatabaseReference doctorRef;
    private Patient patient;
    private EditText healthCardEditText;
    String doctorId;
    List<String> shiftId;
    List<String> doctorsEmployeeNumber;
    private Spinner specialtySpinner;
    private Spinner doctorSpinner;
    private String potentialDate;
    private ArrayList<Calendar> availableDates;
    private ArrayList<String> timeSlots;
    private ListView timeSlotListView;
    private List<String> bookedTimes;
    int startHours;
    int startMins;
    int endHours;
    int endMins;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_book_appointment);

        timeCalendar = Calendar.getInstance();
        date = findViewById(R.id.date);
        calendar = findViewById(R.id.calendar);
        bookAppointmentButton = findViewById(R.id.bookAppointmentButton);
        specialtySelect = findViewById(R.id.specialtySelect);
        doctorSelect = findViewById(R.id.doctorSelect);
        timeSlotListView = findViewById(R.id.timeSlotListView);

        doctorChoices = new ArrayList<String>();
        doctorsEmployeeNumber = new ArrayList<String>();
        availableDates = new ArrayList<>();
        timeSlots = new ArrayList<>();
        bookedTimes = new ArrayList<>();

        specialties = new ArrayList<String>();
        specialties.add("Family Medicine");
        specialties.add("Internal Medicine");
        specialties.add("Pediatrics");
        specialties.add("Obstetrics and Gynecology");

        int hour = timeCalendar.get(Calendar.HOUR_OF_DAY);
        int minute = timeCalendar.get(Calendar.MINUTE);

        doctors = new ArrayList<Doctor>();

        databaseReference = FirebaseDatabase.getInstance().getReference();
        bookAppointmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookAppointment();
            }
        });


        Date currentDate = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedCurrentDate = dateFormat.format(currentDate);
        calendar.setMinDate(System.currentTimeMillis() - 1000);
        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener(){
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                Calendar selectedDate = Calendar.getInstance();
                selectedDate.set(year, month, dayOfMonth);
                if(selectedDate.before(Calendar.getInstance()) && !selectedDate.equals(formattedCurrentDate)) {
                    Toast.makeText(MenuBookAppointment.this, "Please select a future date", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (doctorSelected != null) {
                    checkShiftsAvailability(doctorSelected, selectedDate);
                    displayTimeSlots(selectedDate);
                } else {
                    Toast.makeText(MenuBookAppointment.this, "Please select a doctor first", Toast.LENGTH_SHORT).show();
                }
            }
        });

        specialtySpinner = new Spinner(this);
        doctorSpinner = new Spinner(this);
        specialtySelect.addView(specialtySpinner);
        doctorSelect.addView(doctorSpinner);
        setUpSpecialtySpinner();
    }

    private void bookAppointment() {
        String date = appointmentDay.toString();
        String specialtyApp = specialtySelected.toString();
        String nameDoctor = doctorSelected.toString();
        String time = timeEditText.toString();
        String healthCardNumber = getIntent().getStringExtra("healthCard");
        String firstName = getIntent().getStringExtra("firstName");
        String lastName = getIntent().getStringExtra("lastName");
        String email = getIntent().getStringExtra("email");
        String address = getIntent().getStringExtra("address");
        String phone = getIntent().getStringExtra("phone");

        bookedTimes.add(time);
        DatabaseReference bookedTimesRef = FirebaseDatabase.getInstance().getReference("BookedTimes").child(date);
        bookedTimesRef.setValue(bookedTimes);

        if (nameDoctor != null && date != null && time != null && specialtyApp != null) {
            String appointmentId = UUID.randomUUID().toString();
            String patientName = firstName + " " + lastName;
            String patientId = healthCardNumber.toString();
            String patientEmail = email.toString();
            String patientAddress = address.toString();
            String patientPhoneNumber = phone.toString();
            String status = "pending";

            Appointment appointment = new Appointment(appointmentId, patientName, date, time, status, patientId, nameDoctor, specialtyApp, patientEmail, patientPhoneNumber, patientAddress, doctorId);

            DatabaseReference appointmentReference = databaseReference.child("Appointments").child("pending")
                    .child(patientId).child(appointmentId);
            appointmentReference.setValue(appointment);

            Toast.makeText(this, "Appointment booked successfully", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, ConfirmationActivity.class);
            intent.putExtra("confirmationMessage", "Appointment booked successfully");
            intent.putExtra("healthCard", healthCardNumber);
            intent.putExtra("email", email);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Please fill in all the fields", Toast.LENGTH_SHORT).show();
        }
    }

    private void setUpSpecialtySpinner() {
        LinearLayout.LayoutParams spinnerLayout = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        spinnerLayout.gravity = Gravity.CENTER;
        TextView dynamicView = new TextView(this);
        dynamicView.setLayoutParams(spinnerLayout);
        specialtySelect.addView(dynamicView);

        if (specialtySpinner != null) {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, specialties);
            specialtySpinner.setAdapter(adapter);
            specialtySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    specialtySelected = specialties.get(position);
                    Toast.makeText(MenuBookAppointment.this, "Selected specialty is: " + specialtySelected, Toast.LENGTH_SHORT).show();
                    fetchDoctorsBySpecialty(specialtySelected);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Handle the case where nothing is selected
                }
            });
        }
    }

    private void fetchDoctorsBySpecialty(String selectedSpecialty) {
        DatabaseReference doctorsRef = FirebaseDatabase.getInstance().getReference("accepted").child("acceptedDoctors");
        doctorsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                doctorChoices.clear();
                doctorsEmployeeNumber.clear();

                for (DataSnapshot doctorSnapshot : dataSnapshot.getChildren()) {
                    String firstName = doctorSnapshot.child("firstName").getValue(String.class);
                    String lastName = doctorSnapshot.child("lastName").getValue(String.class);
                    String employeeNumber = doctorSnapshot.child("employeeNumber").getValue(String.class);

                    DataSnapshot specialtiesSnapshot = doctorSnapshot.child("specialty");
                    for (DataSnapshot specialtySnapshot : specialtiesSnapshot.getChildren()) {
                        String doctorSpecialty = specialtySnapshot.getValue(String.class);
                        if (selectedSpecialty.equals(doctorSpecialty)) {
                            doctorChoices.add("Dr." + firstName + " " + lastName);
                            doctorsEmployeeNumber.add(employeeNumber);

                            Doctor doctor = new Doctor();
                            doctor.setFirstName(firstName);
                            doctor.setLastName(lastName);
                            doctor.setEmployeeNumber(employeeNumber);
                            doctors.add(doctor);
                            break;
                        }
                    }
                }

                setUpDoctorSpinner();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle the error
            }
        });
    }


    public void setUpDoctorSpinner() {

        doctorSelect.removeViews(1, doctorSelect.getChildCount() - 1);

        LinearLayout.LayoutParams spinnerLayoutDoc = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        spinnerLayoutDoc.gravity = Gravity.CENTER;
        TextView dynamicViewDoc = new TextView(this);
        dynamicViewDoc.setLayoutParams(spinnerLayoutDoc);
        doctorSelect.addView(dynamicViewDoc);

        if (doctorSpinner != null) {
            ArrayAdapter<String> adapterDoc = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, doctorChoices);
            doctorSpinner.setAdapter(adapterDoc);
            doctorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    // Handle the selected item here
                    doctorSelected = doctorChoices.get(position);
                    doctorId = doctorsEmployeeNumber.get(position);
                    Toast.makeText(MenuBookAppointment.this, "Selected doctor is: " + doctorSelected, Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Handle the case where nothing is selected
                }
            });
        }
    }

    private void checkShiftsAvailability(String doctorName, Calendar selectedDate) {
        DatabaseReference doctorRef = FirebaseDatabase.getInstance().getReference("accepted").child("acceptedDoctors");
        doctorRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot doctorSnapshot : snapshot.getChildren()) {
                    String firstName = doctorSnapshot.child("firstName").getValue(String.class);
                    String lastName = doctorSnapshot.child("lastName").getValue(String.class);
                    String employeeNumber = doctorSnapshot.child("employeeNumber").getValue(String.class);
                    if (("Dr." + firstName + " " + lastName).equals(doctorName)) {
                        doctorId = employeeNumber;
                        break;
                    }
                }
                checkShiftsForDate(selectedDate);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle the error
            }
        });
    }

    private void checkShiftsForDate(Calendar selectedDate) {
        DatabaseReference shiftsRef = FirebaseDatabase.getInstance().getReference("Shifts").child(doctorId);
        shiftsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                availableDates.clear();
                for (DataSnapshot shiftSnapshot : dataSnapshot.getChildren()) {
                    if (shiftSnapshot.hasChild("day") && shiftSnapshot.hasChild("month") && shiftSnapshot.hasChild("year")) {
                        String shiftDate = shiftSnapshot.child("day").getValue().toString();
                        String shiftMonth = shiftSnapshot.child("month").getValue().toString();
                        String shiftYear = shiftSnapshot.child("year").getValue().toString();

                        String paddedMonth = String.format("%02d", Integer.parseInt(shiftMonth));
                        String paddedDate = String.format("%02d", Integer.parseInt(shiftDate));

                        String potentialDate = paddedMonth + "-" + paddedDate + "-" + shiftYear;
                        availableDates.add(convertStringToCalendar(potentialDate));
                    }
                }
                if (isDateAvailable(selectedDate)) {
                    appointmentDay = formatDate(selectedDate);
                    date.setText(appointmentDay);
                    Toast.makeText(MenuBookAppointment.this, "Doctor is available on this date", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MenuBookAppointment.this, "Doctor is not available on this date", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle the error
            }
        });
    }

    public boolean validateTime(int minute) {
        if (minute % 30 != 0) {
            Toast.makeText(this, "Please select a time that is on the hour or half hour", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean isDateAvailable(Calendar selectedDate) {
        for (Calendar availableDate : availableDates) {
            if (selectedDate.get(Calendar.YEAR) == availableDate.get(Calendar.YEAR) &&
                    selectedDate.get(Calendar.MONTH) == availableDate.get(Calendar.MONTH) &&
                    selectedDate.get(Calendar.DAY_OF_MONTH) == availableDate.get(Calendar.DAY_OF_MONTH)) {
                return true;
            }
        }
        return false;
    }

    private String formatDate(Calendar date) {
        int year = date.get(Calendar.YEAR);
        int month = date.get(Calendar.MONTH) + 1;
        int day = date.get(Calendar.DAY_OF_MONTH);

        return String.format("%02d-%02d-%04d", month, day, year);
    }

    private Calendar convertStringToCalendar(String dateString) {
        Calendar calendar = Calendar.getInstance();
        String[] dateParts = dateString.split("-");
        int month = Integer.parseInt(dateParts[0]);
        int day = Integer.parseInt(dateParts[1]);
        int year = Integer.parseInt(dateParts[2]);
        calendar.set(year, month - 1, day);

        return calendar;
    }

    private void displayTimeSlots(Calendar selectedDate) {
        timeSlots.clear();

        DatabaseReference shiftsRef = FirebaseDatabase.getInstance().getReference("Shifts").child(doctorId);
        shiftsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot shiftSnapshot : dataSnapshot.getChildren()) {
                    if (shiftSnapshot.hasChild("day") && shiftSnapshot.hasChild("month") && shiftSnapshot.hasChild("year")) {
                        int shiftDay = shiftSnapshot.child("day").getValue(Integer.class);
                        int shiftMonth = shiftSnapshot.child("month").getValue(Integer.class);
                        int shiftYear = shiftSnapshot.child("year").getValue(Integer.class);

                        if (selectedDate.get(Calendar.YEAR) == shiftYear &&
                                selectedDate.get(Calendar.MONTH) == shiftMonth - 1 &&
                                selectedDate.get(Calendar.DAY_OF_MONTH) == shiftDay) {

                            String startTimeString = shiftSnapshot.child("startTime").getValue(String.class);
                            String endTimeString = shiftSnapshot.child("endTime").getValue(String.class);

                            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.US);
                            try {
                                Date startDate = sdf.parse(startTimeString);
                                Calendar startCalendar = Calendar.getInstance();
                                startCalendar.setTime(startDate);

                                startMins = startCalendar.get(Calendar.MINUTE);
                                startHours = startCalendar.get(Calendar.HOUR_OF_DAY);

                            } catch (ParseException e) {
                                e.printStackTrace();
                                // Handle parsing exception
                            }
                            try {
                                Date endDate = sdf.parse(endTimeString);
                                Calendar endCalendar = Calendar.getInstance();
                                endCalendar.setTime(endDate);

                                endMins = endCalendar.get(Calendar.MINUTE);
                                endHours = endCalendar.get(Calendar.HOUR_OF_DAY);

                            } catch (ParseException e) {
                                e.printStackTrace();
                                // Handle parsing exception
                            }
                            Calendar startTime = Calendar.getInstance();
                            startTime.set(selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH),
                                    selectedDate.get(Calendar.DAY_OF_MONTH), startHours, startMins);

                            Calendar endTime = Calendar.getInstance();
                            endTime.set(selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH),
                                    selectedDate.get(Calendar.DAY_OF_MONTH), endHours, endMins);

                            while (startTime.before(endTime)) {
                                timeSlots.add(formatTime(startTime));
                                startTime.add(Calendar.MINUTE, 30);
                            }

                            getBookedTimeSlots(selectedDate);

                            return;
                        }
                    }
                }

                runOnUiThread(() -> Toast.makeText(MenuBookAppointment.this, "No shift found for the selected day", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle the error
            }
        });
    }

    private String formatTime(Calendar time) {
        int hour = time.get(Calendar.HOUR_OF_DAY);
        int minute = time.get(Calendar.MINUTE);
        return String.format("%02d:%02d %s", (hour == 0 || hour == 12) ? 12 : hour % 12, minute, (hour < 12) ? "AM" : "PM");
    }

    private void getBookedTimeSlots(Calendar selectedDate) {
        DatabaseReference bookedTimesRef = FirebaseDatabase.getInstance().getReference("BookedTimes").child(formatDate(selectedDate));
        bookedTimesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                bookedTimes.clear();
                for (DataSnapshot bookedTimeSnapshot : dataSnapshot.getChildren()) {
                    String bookedTime = bookedTimeSnapshot.getValue(String.class);
                    bookedTimes.add(bookedTime);
                    timeSlots.remove(bookedTime);
                }

                runOnUiThread(() -> {
                    ArrayAdapter<String> timeSlotAdapter = new ArrayAdapter<>(MenuBookAppointment.this, android.R.layout.simple_list_item_1, timeSlots);
                    timeSlotListView.setAdapter(timeSlotAdapter);

                    timeSlotListView.setOnItemClickListener((parent, view, position, id) -> {
                        String selectedTimeSlot = timeSlots.get(position);
                        timeEditText = selectedTimeSlot;
                    });
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle the error
            }
        });
    }
}
