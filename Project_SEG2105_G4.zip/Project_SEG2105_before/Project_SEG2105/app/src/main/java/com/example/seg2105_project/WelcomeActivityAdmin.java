package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivityAdmin extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_admin);
        TextView welcomeMessage = findViewById(R.id.welcomeMessage);
        String role = getIntent().getStringExtra("role");
        welcomeMessage.setText(new StringBuilder().append("Welcome! You are logged in as an ").append(role).toString());
    }

    public void onLogoutClick(View view) {
        Intent intent = new Intent(WelcomeActivityAdmin.this, RoleSelectionActivity.class);
        startActivity(intent);
    }

    public void clickViewPending(View view) {
        Intent adminMenu = new Intent(this, AdminMenuActivity.class);
        startActivity(adminMenu);
    }
}
