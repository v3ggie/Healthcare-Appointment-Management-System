package com.example.seg2105_project;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import android.content.Intent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ShiftCreate extends AppCompatActivity {

    private Spinner startTimeSpinner;
    private Spinner endTimeSpinner;
    private DatePicker datePicker;
    private Button createShiftButton;
    private TextView shiftDetailsTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_shift);

        startTimeSpinner = findViewById(R.id.startTimeSpinner);
        endTimeSpinner = findViewById(R.id.endTimeSpinner);
        datePicker = findViewById(R.id.datePicker);
        createShiftButton = findViewById(R.id.createShiftButton);
        shiftDetailsTextView = findViewById(R.id.shiftDetailsTextView);
        datePicker.setMinDate(System.currentTimeMillis() - 1000);//restricts past dates


        createShiftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String startTime = startTimeSpinner.getSelectedItem().toString();
                String endTime = endTimeSpinner.getSelectedItem().toString();
                int day = datePicker.getDayOfMonth();
                int month = datePicker.getMonth()+1;
                int year = datePicker.getYear();
                String employeeNumber = getIntent().getStringExtra("employeeNumber");
                String shiftId = UUID.randomUUID().toString(); // Generate a unique ID

                List<String> specialties = getIntent().getStringArrayListExtra("specialties");

                if (specialties != null && employeeNumber != null) {
                    Shift newShift = new Shift(startTime, endTime, day, month, year, employeeNumber, specialties, shiftId);
                    isShiftOverlap(newShift);
                } else {
                    Toast.makeText(ShiftCreate.this, "Doctor not found for the given employee number", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    private void createShift(Shift shift) {
        int day = shift.getDay();
        int month = shift.getMonth();
        int year = shift.getYear();
        int currentDay = java.time.LocalDate.now().getDayOfMonth();
        int currentMonth = java.time.LocalDate.now().getMonthValue();
        int currentYear = java.time.LocalDate.now().getYear();

        if (year < currentYear || (year == currentYear && month < currentMonth) || (year == currentYear && month == currentMonth && day < currentDay)) {
            Toast.makeText(this, "Please select a future date", Toast.LENGTH_SHORT).show();
            return;
        }

        String employeeNumber = shift.getEmployeeNumber();
        String shiftId = shift.getShiftId();
        String startTime = shift.getStartTime();
        String endTime = shift.getEndTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
        try{
            Date startCheck = dateFormat.parse(startTime);
            Date endCheck = dateFormat.parse(endTime);
            if (startCheck.compareTo(endCheck) >= 0) {
                Toast.makeText(this, "Start time must be before end time", Toast.LENGTH_SHORT).show();
                return;
            }
        }catch(ParseException e){
            e.printStackTrace();
        }

        DatabaseReference shiftsRef = FirebaseDatabase.getInstance().getReference("Shifts").child(employeeNumber).child(shiftId);

        // Check for conflicts with previously added shift
        shiftsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Shift existingShift = dataSnapshot.getValue(Shift.class);

                if (existingShift != null && isOverlap(existingShift, shift)) {
                    Toast.makeText(ShiftCreate.this, "Shift conflicts with a previous shift", Toast.LENGTH_SHORT).show();
                } else {
                    DatabaseReference doctorsRef = FirebaseDatabase.getInstance().getReference("accepted").child("acceptedDoctors");
                    doctorsRef.child(employeeNumber).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            List<String> specialties = shift.getSpecialties();

                            if (specialties != null && employeeNumber != null) {
                                // Adds or updates shift in the DB
                                updateShiftsInDatabase(shift);
                                Toast.makeText(ShiftCreate.this, "Shift created successfully", Toast.LENGTH_LONG).show();
                                updateShiftDetailsTextView(shift);
                                Intent intent = new Intent(ShiftCreate.this, ConfirmationActivityDoc.class);
                                intent.putExtra("confirmationMessage", "Shift created successfully");
                                intent.putExtra("employeeNumber", employeeNumber);
                                intent.putExtra("email", getIntent().getStringExtra("email"));
                                startActivity(intent);
                            } else {
                                Toast.makeText(ShiftCreate.this, "Doctor not found for the given employee number", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            // Handle the error
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle the error
            }
        });
    }

    private void updateShiftDetailsTextView(Shift shift) {
        String shiftDetails = "Date: " + shift.getDay() + "/" + shift.getMonth() + "/" + shift.getYear() +
                "\nStart Time: " + shift.getStartTime() +
                "\nEnd Time: " + shift.getEndTime() +
                "\nEmployee Number: " + shift.getEmployeeNumber() +
                "\nSpecialties: " + shift.getSpecialties().toString() +
                "\nAppointment ID: " + shift.getShiftId();
        shiftDetailsTextView.setText(shiftDetails);
    }

    private void updateShiftsInDatabase(Shift shift) {
        try {
            DatabaseReference shiftsRef = FirebaseDatabase.getInstance().getReference("Shifts").child(shift.getEmployeeNumber().toString());

            //  = key for the shift
            shiftsRef.child(shift.getShiftId()).setValue(shift);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isOverlap(Shift existingShift, Shift newShift) {
        if (existingShift.getYear() != newShift.getYear() || existingShift.getMonth() != newShift.getMonth() || existingShift.getDay() != newShift.getDay()) {
            return false;
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
        try {
            Date existingStartTime = dateFormat.parse(existingShift.getStartTime());
            Date existingEndTime = dateFormat.parse(existingShift.getEndTime());
            Date newStartTime = dateFormat.parse(newShift.getStartTime());
            Date newEndTime = dateFormat.parse(newShift.getEndTime());

            return !(newEndTime.compareTo(existingStartTime) <= 0 || newStartTime.compareTo(existingEndTime) >= 0);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }



    private void isShiftOverlap(Shift newShift) {
        String employeeNumber = getIntent().getStringExtra("employeeNumber");
        DatabaseReference shiftsRef = FirebaseDatabase.getInstance().getReference("Shifts").child(employeeNumber);

        shiftsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot shiftSnapshot : dataSnapshot.getChildren()) {
                    String shiftId = shiftSnapshot.getKey();
                    String startTime = shiftSnapshot.child("startTime").getValue(String.class);
                    String endTime = shiftSnapshot.child("endTime").getValue(String.class);
                    int day = shiftSnapshot.child("day").getValue(Integer.class);
                    int month = shiftSnapshot.child("month").getValue(Integer.class);
                    int year = shiftSnapshot.child("year").getValue(Integer.class);

                    // Now you have individual shift details to check for overlap
                    Shift existingShift = new Shift(startTime, endTime, day, month, year, employeeNumber, null, shiftId);

                    if (existingShift != null && isOverlap(existingShift, newShift)) {
                        // There is an overlap
                        Toast.makeText(ShiftCreate.this, "Shift conflicts with a previous shift", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                createShift(newShift);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle the error
            }
        });
    }
}
