package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginAdminActivity extends AppCompatActivity {

    private EditText emailEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_admin);

        databaseReference = FirebaseDatabase.getInstance().getReference("admins");

        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String enteredEmail = emailEditText.getText().toString();
                final String enteredPassword = passwordEditText.getText().toString();

                if (validateFields()) {
                    checkAdminCredentials(enteredEmail, enteredPassword);
                }
            }
        });
    }

    private void checkAdminCredentials(final String enteredEmail, final String enteredPassword) {
        DatabaseReference adminsRef = databaseReference.child("admin1");

        adminsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String adminEmail = dataSnapshot.child("email").getValue(String.class);
                    String adminPassword = dataSnapshot.child("password").getValue(String.class);

                    if (adminEmail != null && adminPassword != null) {
                        if (enteredEmail.equals(adminEmail) && enteredPassword.equals(adminPassword)) {
//                            showWelcomeScreen("Admin");
                            Intent intent = new Intent(LoginAdminActivity.this, WelcomeAdmin.class);
                            startActivity(intent);
                        } else {
                            showCustomError("Invalid email or password");
                        }
                    } else {
                        showCustomError("Invalid email or password");
                    }
                } else {
                    showCustomError("Invalid email or password");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                showCustomError("Database error: " + databaseError.getMessage());
            }
        });
    }

    private void showCustomError(String errorMessage) {
        emailEditText.setError(errorMessage);
        passwordEditText.setError(errorMessage);
    }

    private boolean validateFields() {
        boolean isValid = true;
        if (emailEditText.getText().toString().trim().isEmpty()) {
            emailEditText.setError("Email cannot be empty");
            isValid = false;
        } else {
            emailEditText.setError(null);
        }
        if (passwordEditText.getText().toString().trim().isEmpty()) {
            passwordEditText.setError("Password cannot be empty");
            isValid = false;
        } else {
            passwordEditText.setError(null);
        }
        return isValid;
    }

    private void showWelcomeScreen(String role) {
        Intent intent = new Intent(LoginAdminActivity.this, WelcomeAdmin.class);
        intent.putExtra("role", role);
        startActivity(intent);
    }


}
