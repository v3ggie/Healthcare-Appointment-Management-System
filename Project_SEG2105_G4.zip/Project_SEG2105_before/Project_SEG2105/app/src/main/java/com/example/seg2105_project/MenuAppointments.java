package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MenuAppointments extends AppCompatActivity {
    LinearLayout containerLayout;
    String email;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_menu_appointments);
        containerLayout = findViewById(R.id.containerP);
        String healthCardNumber = getIntent().getStringExtra("healthCard");
        searchShifts(healthCardNumber.toString());
    }

    public void searchShifts(String healthCard) {
        containerLayout.removeAllViews();
            try {
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Appointments").child("pending").child(healthCard.toString());
                databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Date currentDate = Calendar.getInstance().getTime();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd--yyyy");
                        String formattedCurrentDate = dateFormat.format(currentDate);

                        for (DataSnapshot patientSnapshot : dataSnapshot.getChildren()) {
                            String patientName = patientSnapshot.child("patientName").getValue(String.class);
                            String date = patientSnapshot.child("date").getValue(String.class);
                            String time = patientSnapshot.child("time").getValue(String.class);
                            String doctorId = patientSnapshot.child("doctorId").getValue(String.class);
                            String healthCardNumber = patientSnapshot.child("patientId").getValue(String.class);
                            String specialty = patientSnapshot.child("specialty").getValue(String.class);
                            String appointmentId = patientSnapshot.child("appointmentId").getValue(String.class);
                            String status = patientSnapshot.child("status").getValue(String.class);
                            email = patientSnapshot.child("email").getValue(String.class);


                            if (isFutureDate(date, formattedCurrentDate) && patientName != null && doctorId != null && date != null && time != null) {
                                LinearLayout appointmentLayout = new LinearLayout(MenuAppointments.this);
                                appointmentLayout.setOrientation(LinearLayout.VERTICAL);

                                TextView textView = new TextView(MenuAppointments.this);
                                textView.setText(String.format("Doctor: %s\nTime: %s\nDate: %s\nSpecialty: %s\nStatus: Pending",
                                        doctorId, time, date, specialty));
                                textView.setTextColor(getResources().getColor(android.R.color.white));
                                textView.setBackgroundResource(R.drawable.textview_background);
                                LinearLayout.LayoutParams textLayoutParams = new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        LinearLayout.LayoutParams.WRAP_CONTENT
                                );
                                textView.setLayoutParams(textLayoutParams);
                                int paddingValueInDp = 14;
                                int paddingValueInPixels = (int) (paddingValueInDp * getResources().getDisplayMetrics().density);
                                textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);

                                Button cancelButton = new Button(MenuAppointments.this);
                                cancelButton.setText("Cancel");

                                final LinearLayout finalAppointmentLayout = appointmentLayout;

                                if (!isWithinAnHour(date, time)) {
                                    cancelButton.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            cancelAppointment(healthCardNumber, appointmentId, status);
                                            containerLayout.removeView(finalAppointmentLayout);
                                        }
                                    });
                                } else {
                                    // Optionally, you can disable the button or show a message
                                    cancelButton.setEnabled(false);
                                    // You may want to set a different color or style for disabled buttons
                                    cancelButton.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
                                }

                                appointmentLayout.addView(textView);
                                appointmentLayout.addView(cancelButton);

                                containerLayout.addView(appointmentLayout);
                            } else {
                                Toast.makeText(MenuAppointments.this, "No appointments found", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // Handle errors
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                DatabaseReference databaseReference2 = FirebaseDatabase.getInstance().getReference("Appointments").child("approved").child(healthCard.toString());
                databaseReference2.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Date currentDate = Calendar.getInstance().getTime();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
                        String formattedCurrentDate = dateFormat.format(currentDate);

                        for (DataSnapshot patientSnapshot : dataSnapshot.getChildren()) {
                            String patientName = patientSnapshot.child("patientName").getValue(String.class);
                            String date = patientSnapshot.child("date").getValue(String.class);
                            String time = patientSnapshot.child("time").getValue(String.class);
                            String doctorId = patientSnapshot.child("doctorId").getValue(String.class);
                            String healthCardNumber = patientSnapshot.child("patientId").getValue(String.class);
                            String specialty = patientSnapshot.child("specialty").getValue(String.class);
                            String appointmentId = patientSnapshot.child("appointmentId").getValue(String.class);
                            String status = patientSnapshot.child("status").getValue(String.class);
                            email = patientSnapshot.child("email").getValue(String.class);

                            if (isFutureDate(date, formattedCurrentDate) && patientName != null && doctorId != null && date != null && time != null) {
                                LinearLayout appointmentLayout = new LinearLayout(MenuAppointments.this);
                                appointmentLayout.setOrientation(LinearLayout.VERTICAL);

                                TextView textView = new TextView(MenuAppointments.this);
                                textView.setText(String.format("Doctor: %s\nTime: %s\nDate: %s\nSpecialty: %s\nStatus: Approved",
                                        doctorId, time, date, specialty));
                                textView.setTextColor(getResources().getColor(android.R.color.white));
                                textView.setBackgroundResource(R.drawable.textview_background);
                                LinearLayout.LayoutParams textLayoutParams = new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        LinearLayout.LayoutParams.WRAP_CONTENT
                                );
                                textView.setLayoutParams(textLayoutParams);
                                int paddingValueInDp = 14;
                                int paddingValueInPixels = (int) (paddingValueInDp * getResources().getDisplayMetrics().density);
                                textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);

                                Button cancelButton = new Button(MenuAppointments.this);
                                cancelButton.setText("Cancel");

                                final LinearLayout finalAppointmentLayout = appointmentLayout;

                                if (!isWithinAnHour(date, time)) {
                                    cancelButton.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            cancelAppointment(healthCardNumber, appointmentId, status);
                                            containerLayout.removeView(finalAppointmentLayout);
                                        }
                                    });
                                } else {
                                    // Optionally, you can disable the button or show a message
                                    cancelButton.setEnabled(false);
                                    // You may want to set a different color or style for disabled buttons
                                    cancelButton.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
                                }

                                appointmentLayout.addView(textView);
                                appointmentLayout.addView(cancelButton);

                                containerLayout.addView(appointmentLayout);
                            } else {
                                Toast.makeText(MenuAppointments.this, "No appointments found", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // Handle errors
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
    }

    private void cancelAppointment(String healthCardNumber,String appointmentId, String status){
        try {
            DatabaseReference appointmentsRef;

            // Choose the appropriate node based on the status
            if ("approved".equals(status)) {
                appointmentsRef = FirebaseDatabase.getInstance()
                        .getReference("Appointments")
                        .child("approved")
                        .child(healthCardNumber)
                        .child(appointmentId);
            } else if ("pending".equals(status)) {
                appointmentsRef = FirebaseDatabase.getInstance()
                        .getReference("Appointments")
                        .child("pending")
                        .child(healthCardNumber)
                        .child(appointmentId);
            } else {
                return;
            }
            // Remove the appointment
            appointmentsRef.removeValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void goBack(View view) {
        Intent intent = new Intent(MenuAppointments.this, MenuPatient.class);
        String healthCard = getIntent().getStringExtra("healthCard");
        intent.putExtra("healthCard", healthCard);
        intent.putExtra("email", email);
        startActivity(intent);
    }

    private boolean isFutureDate(String appointmentDate, String currentDate) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
            Date date1 = dateFormat.parse(appointmentDate);
            Date date2 = dateFormat.parse(currentDate);

            return date1 != null && date1.after(date2);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean isWithinAnHour(String appointmentDate, String appointmentTime) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm");
            Date appointmentDateTime = dateFormat.parse(appointmentDate + " " + appointmentTime);

            if (appointmentDateTime != null) {
                Date currentDate = Calendar.getInstance().getTime();

                long difference = appointmentDateTime.getTime() - currentDate.getTime();
                long differenceInMinutes = difference / (60 * 1000);

                return differenceInMinutes <= 60;
            } else {
                // Log a message or handle the case where parsing fails
                return false;
            }
        } catch (Exception e) {
            // Log the exception or handle it as needed
            e.printStackTrace();
            return false;
        }
    }
}
