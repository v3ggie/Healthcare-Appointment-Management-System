package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeDoctor extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_doctor);
        TextView welcomeMessage = findViewById(R.id.welcomeMessage);
        String role = getIntent().getStringExtra("role");
        welcomeMessage.setText("Welcome Doctor! You are logged in.");
    }

    public void onNextClick(View view) {
        Intent intent = new Intent(WelcomeDoctor.this, MenuDoctor.class);
        String email = getIntent().getStringExtra("email");
        String firstName = getIntent().getStringExtra("firstName");
        String lastName = getIntent().getStringExtra("lastName");
        intent.putExtra("email", email);
        intent.putExtra("firstName", firstName);
        intent.putExtra("lastName", lastName);
        startActivity(intent);
    }
    public void onLogoutClick(View view) {
        Intent intent = new Intent(WelcomeDoctor.this, RoleSelectionActivity.class);
        startActivity(intent);
    }

}
