package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SearchShiftsActivity extends AppCompatActivity {

    private LinearLayout containerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_shifts);

        containerLayout = findViewById(R.id.containerLayout);

        String employeeNumber = getIntent().getStringExtra("employeeNumber");
        searchShifts(employeeNumber);
    }

    private void searchShifts(String employeeNumber) {
        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Shifts").child(employeeNumber.toString());
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot doctorSnapshot : dataSnapshot.getChildren()) {
                        String day = doctorSnapshot.child("day").getValue().toString();
                        String employeeNumber = doctorSnapshot.child("employeeNumber").getValue().toString();
                        String endTime = doctorSnapshot.child("endTime").getValue().toString();
                        String month = doctorSnapshot.child("month").getValue().toString();
                        String startTime = doctorSnapshot.child("startTime").getValue().toString();
                        String shiftId = doctorSnapshot.child("shiftId").getValue().toString();
                        String year = doctorSnapshot.child("year").getValue().toString();

                        if (day != null && employeeNumber != null && endTime != null && month != null && startTime != null && shiftId != null) {
                            LinearLayout shiftLayout = new LinearLayout(SearchShiftsActivity.this);
                            shiftLayout.setOrientation(LinearLayout.VERTICAL);

                            TextView textView = new TextView(SearchShiftsActivity.this);
                            textView.setText(String.format("Day: %s\nMonth: %s\nStart time: %s\nEnd time: %s\n",
                                    day, month, startTime, endTime));
                            textView.setTextColor(getResources().getColor(android.R.color.white));
                            textView.setBackgroundResource(R.drawable.textview_background);
                            LinearLayout.LayoutParams textLayoutParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT
                            );
                            textView.setLayoutParams(textLayoutParams);
                            int paddingValueInDp = 14;
                            int paddingValueInPixels = (int) (paddingValueInDp * getResources().getDisplayMetrics().density);
                            textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);

                            Button cancelButton = new Button(SearchShiftsActivity.this);
                            cancelButton.setText("Cancel");

                            cancelButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    hasLinkedAppointments(employeeNumber, day, month, year, new AppointmentsCallback() {
                                        @Override
                                        public void onAppointmentsChecked(boolean hasLinkedAppointments) {
                                            if (!hasLinkedAppointments) {
                                                cancelShift(employeeNumber, shiftId);
                                                containerLayout.removeView(shiftLayout);
                                            } else {
                                                Toast.makeText(SearchShiftsActivity.this, "Cannot cancel this shift as it is linked to appointments.", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                }
                            });

                            shiftLayout.addView(textView);
                            shiftLayout.addView(cancelButton);

                            containerLayout.addView(shiftLayout);
                        }else {
                            Toast.makeText(SearchShiftsActivity.this, "No shifts found", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle errors
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



    public static void cancelShift(String employeeNumber, String shiftId) {
        try {
            // removes appointments from the Appointments node
            DatabaseReference appointmentsRef = FirebaseDatabase.getInstance()
                    .getReference("Shifts")
                    .child(employeeNumber)
                    .child(shiftId);
            appointmentsRef.removeValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void goBack(View view) {
        Intent intent = new Intent(SearchShiftsActivity.this, MenuDoctor.class);
        String employeeNumber = getIntent().getStringExtra("employeeNumber");
        intent.putExtra("employeeNumber", employeeNumber);
        String email = getIntent().getStringExtra("email");
        intent.putExtra("email", email);
        startActivity(intent);
    }


    public void hasLinkedAppointments(String employeeNumber, String day, String month, String year, AppointmentsCallback callback) {
        String shiftDate = String.format("%s-%s-%s", month, day, year);

        try {
            DatabaseReference appointmentsRef = FirebaseDatabase.getInstance().getReference("Appointments").child("approved");
            appointmentsRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    boolean linkedAppointments = false;
                    for (DataSnapshot patientSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot appointmentSnapshot : patientSnapshot.getChildren()) {
                            String appointmentDate = appointmentSnapshot.child("date").getValue(String.class);
                            String appointmentDoctor = appointmentSnapshot.child("doctorEmployeeNumber").getValue(String.class);
                            if (appointmentDate != null && appointmentDate.equals(shiftDate)
                                    && appointmentDoctor != null && appointmentDoctor.equals(employeeNumber)) {
                                linkedAppointments = true;
                                break;
                            }
                        }
                        if (linkedAppointments) {
                            break;
                        }
                    }
                    callback.onAppointmentsChecked(linkedAppointments);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e("Firebase", "Error reading appointments data", databaseError.toException());
                    callback.onAppointmentsChecked(false); // Handle the error case
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            callback.onAppointmentsChecked(false); // Handle the exception case
        }
    }
}

