package com.example.seg2105_project;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;
import java.util.List;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MenuDoctor extends AppCompatActivity {

    private TextView welcomeMessage;
    private String firstName;
    private String lastName;
    private String employeeNumberDoctor;
    private String specialtyDoctor;
    private List<String> specialties;
    private String emailDoctor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_doctor);

        welcomeMessage = findViewById(R.id.title);

        String email = getIntent().getStringExtra("email");

        retrieveEmployeeNumber(email);
    }

    private void retrieveEmployeeNumber(String email) {
        // Retrieve the patient's details from the database
        DatabaseReference doctorsRef = FirebaseDatabase.getInstance().getReference("accepted").child("acceptedDoctors");
        doctorsRef.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // Patient data found, update the welcome message
                    DataSnapshot doctorSnapshot = dataSnapshot.getChildren().iterator().next();
                    firstName = doctorSnapshot.child("firstName").getValue(String.class);
                    lastName = doctorSnapshot.child("lastName").getValue(String.class);
                    String patientName = firstName + " " + lastName;
                    employeeNumberDoctor = doctorSnapshot.child("employeeNumber").getValue(String.class);
                    emailDoctor = doctorSnapshot.child("email").getValue(String.class);

                    specialties = new ArrayList<String>();
                    for (DataSnapshot specialtySnapshot : doctorSnapshot.child("specialty").getChildren()) {
                        String specialty = specialtySnapshot.getValue(String.class);
                        specialties.add(specialty);
                    }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("MenuPatient", "Error reading data: " + databaseError.getMessage());
            }
        });
    }

    public void onShiftClick(View view) {
        Intent intent = new Intent(MenuDoctor.this, ShiftCreate.class);
        String firstName = getIntent().getStringExtra("firstName");
        String lastName = getIntent().getStringExtra("lastName");
        intent.putExtra("firstName", firstName);
        intent.putExtra("lastName", lastName);
        intent.putExtra("employeeNumber", employeeNumberDoctor);
        intent.putStringArrayListExtra("specialties", (ArrayList<String>) specialties);
        intent.putExtra("email", emailDoctor);
        startActivity(intent);
    }

    public void onShiftViewClick(View view) {
        Intent intent = new Intent(MenuDoctor.this, SearchShiftsActivity.class);
        intent.putExtra("employeeNumber", employeeNumberDoctor);
        intent.putExtra("email", emailDoctor);
        startActivity(intent);
    }

    public void onAppClick(View view) {
        Intent intent = new Intent(MenuDoctor.this, ApprovedAppointmentsDoctor.class);
        intent.putExtra("employeeNumber", employeeNumberDoctor);
        intent.putExtra("email", emailDoctor);
        startActivity(intent);
    }

    public void onPastAppClick(View view) {
        Intent intent = new Intent(MenuDoctor.this, PastAppointmentsDoctor.class);
        intent.putExtra("employeeNumber", employeeNumberDoctor);
        intent.putExtra("email", emailDoctor);
        startActivity(intent);
    }

    public void onPendingAppClick(View view) {
        Intent intent = new Intent(MenuDoctor.this, PendingAppointmentsDoctor.class);
        intent.putExtra("employeeNumber", employeeNumberDoctor);
        intent.putExtra("email", emailDoctor);
        startActivity(intent);
    }

    public void onLogoutClick(View view) {
        Intent intent = new Intent(MenuDoctor.this, RoleSelectionActivity.class);
        startActivity(intent);
    }
}
