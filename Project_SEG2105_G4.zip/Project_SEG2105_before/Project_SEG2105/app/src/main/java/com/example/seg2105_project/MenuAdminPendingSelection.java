package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MenuAdminPendingSelection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.menu_pending_selection);
    }

    public void onDoctorClick(View view) {
        Intent intent = new Intent(MenuAdminPendingSelection.this, ViewPendingDoctors.class);
        startActivity(intent);
    }

    public void onPatientClick(View view) {
        Intent intent = new Intent(MenuAdminPendingSelection.this, ViewPendingPatients.class);
        startActivity(intent);
    }

    public void onMenuClick(View view) {
        Intent intent = new Intent(MenuAdminPendingSelection.this, MenuAdmin.class);
        startActivity(intent);
    }

}
