package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ConfirmationActivityDoc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation_doc);

        String confirmationMessage = getIntent().getStringExtra("confirmationMessage");

        TextView confirmationTextView = findViewById(R.id.confirmationMessage);
        if (confirmationMessage != null && !confirmationMessage.isEmpty()) {
            confirmationTextView.setText(confirmationMessage);
        } else {
            confirmationTextView.setText("Shift booked successfully!");
        }

        Button logoutButton = findViewById(R.id.logoutButton);
        Button backButton = findViewById(R.id.backButton);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToMenu();
            }
        });
    }

    public void logout() {
        Intent intent = new Intent(this, RoleSelectionActivity.class);
        startActivity(intent);
    }

    public void backToMenu() {
        Intent intent = new Intent(this, MenuDoctor.class);
        String employeeNumber = getIntent().getStringExtra("employeeNumber");
        String email = getIntent().getStringExtra("email");
        intent.putExtra("email", email);
        intent.putExtra("employeeNumber", employeeNumber);
        startActivity(intent);
    }
}
