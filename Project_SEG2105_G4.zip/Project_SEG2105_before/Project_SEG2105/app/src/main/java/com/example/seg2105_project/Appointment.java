package com.example.seg2105_project;

import java.io.Serializable;

public class Appointment implements Serializable {
    private String appointmentId;
    private String patientName;
    private String date;
    private String time;
    private String status;
    private String patientId;
    private String doctorId;
    private String specialty;
    private String email;
    private String phoneNumber;
    private String address;
    private String doctorEmployeeNumber;


    public Appointment(String appointmentId, String patientName, String date, String time, String status, String patientId, String doctorId, String specialty, String email, String phoneNumber, String address, String doctorEmployeeNumber) {
        this.appointmentId = appointmentId;
        this.patientName = patientName;
        this.date = date;
        this.time = time;
        this.status = status;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.specialty = specialty;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.doctorEmployeeNumber = doctorEmployeeNumber;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getPatientNameFromId(String patientId) {
        if (patientId.equals(this.patientId)) {
            return this.patientName;
        }
        return "Unknown Patient";
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDoctorEmployeeNumber() {
        return doctorEmployeeNumber;
    }

    public void setDoctorEmployeeNumber(String doctorEmployeeNumber) {
        this.doctorEmployeeNumber = doctorEmployeeNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}