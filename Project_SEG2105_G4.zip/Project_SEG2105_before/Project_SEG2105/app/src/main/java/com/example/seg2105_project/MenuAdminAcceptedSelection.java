package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MenuAdminAcceptedSelection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.menu_accepted_selection);
    }

    public void onDoctorClick(View view) {
        Intent intent = new Intent(MenuAdminAcceptedSelection.this, ViewAcceptedDoctors.class);
        startActivity(intent);
    }

    public void onPatientClick(View view) {
        Intent intent = new Intent(MenuAdminAcceptedSelection.this, ViewAcceptedPatients.class);
        startActivity(intent);
    }

    public void onMenuClick(View view) {
        Intent intent = new Intent(MenuAdminAcceptedSelection.this, MenuAdmin.class);
        startActivity(intent);
    }

}
