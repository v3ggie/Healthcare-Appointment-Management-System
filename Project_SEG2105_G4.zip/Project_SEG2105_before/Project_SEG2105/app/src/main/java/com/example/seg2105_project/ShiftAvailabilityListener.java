package com.example.seg2105_project;

public interface ShiftAvailabilityListener {
    void onResult(boolean isAvailable);
}
