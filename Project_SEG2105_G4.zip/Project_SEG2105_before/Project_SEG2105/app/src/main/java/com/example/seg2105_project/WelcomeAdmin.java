package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeAdmin extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_admin);
        TextView welcomeMessage = findViewById(R.id.welcomeMessage);
        String role = getIntent().getStringExtra("role");
        welcomeMessage.setText(new StringBuilder().append("Welcome! You are logged in as admin"));
    }

    public void onLogoutClick(View view) {
        Intent intent = new Intent(WelcomeAdmin.this, RoleSelectionActivity.class);
        startActivity(intent);
    }

    public void onNextClick(View view) {
        Intent intent = new Intent(WelcomeAdmin.this, MenuAdmin.class);
        startActivity(intent);
    }
}
