package com.example.seg2105_project;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.graphics.drawable.Drawable;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MenuPastAppointments extends AppCompatActivity {
    LinearLayout containerLayout;
    String email;
    private DatabaseReference databaseReference;
    private RatingBar rateButton;
    private boolean appointmentsFound;
    private String oldRating;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_menu_past_appointments);
        containerLayout = findViewById(R.id.containerP);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        String healthCardNumber = getIntent().getStringExtra("healthCard");
        searchAppointments(healthCardNumber);
    }

    private void searchAppointments(String healthCard) {
        containerLayout.removeAllViews();
        Date currentDate = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        String formattedCurrentDate = dateFormat.format(currentDate);
        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Appointments").child("approved").child(healthCard);
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot patientSnapshot : dataSnapshot.getChildren()) {
                        appointmentsFound = false;
                        String patientName = patientSnapshot.child("patientName").getValue(String.class);
                        String date = patientSnapshot.child("date").getValue(String.class);
                        String time = patientSnapshot.child("time").getValue(String.class);
                        String doctorId = patientSnapshot.child("doctorId").getValue(String.class);
                        String healthCardNumber = patientSnapshot.child("healthCard").getValue(String.class);
                        String specialty = patientSnapshot.child("specialty").getValue(String.class);
                        String appointmentId = patientSnapshot.child("appointmentId").getValue(String.class);
                        String status = patientSnapshot.child("status").getValue(String.class);
                        String employeeNumber = patientSnapshot.child("doctorEmployeeNumber").getValue(String.class);
                        email = patientSnapshot.child("email").getValue(String.class);

                        if (isPastDate(date, formattedCurrentDate) && patientName != null && doctorId != null && date != null && time != null) {
                            isRated(doctorId, date, time, specialty, status, appointmentId, healthCardNumber, employeeNumber);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle errors
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void goBack(View view) {
        Intent intent = new Intent(MenuPastAppointments.this, MenuPatient.class);
        String healthCard = getIntent().getStringExtra("healthCard");
        intent.putExtra("healthCard", healthCard);
        intent.putExtra("email", email);
        startActivity(intent);
    }

    private boolean isPastDate(String appointmentDate, String currentDate) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
            Date date1 = dateFormat.parse(appointmentDate);
            Date date2 = dateFormat.parse(currentDate);

            return date1 != null && date1.before(date2);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void rateAppointment(String employeeNumber, String appointmentId, float rating, String healthCardNumber) {
        DatabaseReference ratingReference = databaseReference.child("Ratings").child(employeeNumber).child(appointmentId);
        ratingReference.child("rating").setValue(String.valueOf(rating));
        ratingReference.child("healthCard").setValue(healthCardNumber);

        Toast.makeText(MenuPastAppointments.this, "Rating submitted successfully", Toast.LENGTH_SHORT).show();
    }

    private void isRated(String doctorId, String date, String time, String specialty, String status, String appointmentId, String healthCardNumber, String employeeNumber) {
        DatabaseReference ratingReference = FirebaseDatabase.getInstance().getReference("Ratings").child(employeeNumber).child(appointmentId);
        ratingReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String pastRating = "0"; // Default value if no rating is found
                if (dataSnapshot.exists()) {
                    pastRating = dataSnapshot.child("rating").getValue(String.class);
                }
                oldRating = pastRating;
                initializeViews(doctorId, date, time, specialty, status, appointmentId, healthCardNumber, employeeNumber, oldRating);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle errors
            }
        });
    }

    private void initializeViews(String doctorId, String date, String time, String specialty, String status, String appointmentId, String healthCardNumber, String employeeNumber, String rating) {
        if (!appointmentsFound) {
            LinearLayout appointmentLayout = new LinearLayout(MenuPastAppointments.this);
            appointmentLayout.setOrientation(LinearLayout.VERTICAL);

            TextView textView = new TextView(MenuPastAppointments.this);
            textView.setText(String.format("Doctor: %s\nTime: %s\nDate: %s\nSpecialty: %s\nStatus: %s",
                    doctorId, time, date, specialty, status));
            textView.setTextColor(getResources().getColor(android.R.color.white));
            textView.setBackgroundResource(R.drawable.textview_background);
            LinearLayout.LayoutParams textLayoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            textView.setLayoutParams(textLayoutParams);
            int paddingValueInDp = 14;
            int paddingValueInPixels = (int) (paddingValueInDp * getResources().getDisplayMetrics().density);
            textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);

            RatingBar rateButton = new RatingBar(MenuPastAppointments.this);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, // Set width
                    LinearLayout.LayoutParams.WRAP_CONTENT // Set height
            );
            layoutParams.gravity = Gravity.CENTER_HORIZONTAL;
            rateButton.setLayoutParams(layoutParams);
            rateButton.setNumStars(5);
            rateButton.setStepSize(1);
            rateButton.setProgressTintList(ColorStateList.valueOf(Color.WHITE));
            rateButton.setRating(Float.parseFloat(rating));

            rateButton.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                @Override
                public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                    rateAppointment(employeeNumber, appointmentId, rating, healthCardNumber);
                    //Toast.makeText(MenuPastAppointments.this, "Rating submitted successfully" + rating, Toast.LENGTH_SHORT).show();
                }
            });

            appointmentLayout.addView(textView);
            appointmentLayout.addView(rateButton);

            containerLayout.addView(appointmentLayout);
            appointmentsFound = true;
        }
    }
}
