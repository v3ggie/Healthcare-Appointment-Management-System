package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class PendingRegistration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pending_registration);
    }

    public void onLogoutClick(View view) {
        Intent intent = new Intent(PendingRegistration.this, RoleSelectionActivity.class);
        startActivity(intent);
    }
}
