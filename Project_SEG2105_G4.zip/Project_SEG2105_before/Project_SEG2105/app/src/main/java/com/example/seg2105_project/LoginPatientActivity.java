package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginPatientActivity extends AppCompatActivity {

    private EditText emailEditText;
    private EditText passwordEditText;
    private Button logInButton;
    private Button signUpButton;
    private View loginLayout;
    private String firstName;
    private String lastName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_patient);

        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        logInButton = findViewById(R.id.loginButton);
        signUpButton = findViewById(R.id.signUpButton);

        String role = getIntent().getStringExtra("role");

        TextView loginTitle = findViewById(R.id.loginTitle);
        loginTitle.setText(role + " Login");

        loginLayout = findViewById(R.id.loginLayout);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String role = getIntent().getStringExtra("role");
                Intent intent = new Intent(LoginPatientActivity.this, PatientRegistration.class);
                startActivity(intent);
            }
        });

        logInButton.setOnClickListener(new View.OnClickListener() {
            boolean isPatientFound = false;
            @Override
            public void onClick(View v) {
                if (validateFields()) {
                    // Get user input
                    String email = emailEditText.getText().toString().trim();
                    String password = passwordEditText.getText().toString().trim();

                    // Firebase authentication logic
                    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("accepted").child("acceptedPatients");
                    databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot1) {
                            isPatientFound = false;
                            for (DataSnapshot patientSnapshot : dataSnapshot1.getChildren()) {
                                String patientEmail = patientSnapshot.child("email").getValue(String.class);
                                String patientPassword = patientSnapshot.child("password").getValue(String.class);
                                firstName = patientSnapshot.child("firstName").getValue(String.class);
                                lastName = patientSnapshot.child("lastName").getValue(String.class);

                                if (email.equals(patientEmail) && password.equals(patientPassword)) {
                                    isPatientFound = true;
                                    break;
                                }
                            }

                            if (isPatientFound) {
                                // Patient found, proceed to the next activity
                                Intent intent = new Intent(LoginPatientActivity.this, WelcomePatient.class);
                                intent.putExtra("email", email);
                                intent.putExtra("firstName", firstName);
                                intent.putExtra("lastName", lastName);
                                startActivity(intent);
                            } else {
                                // Patient not found or credentials are incorrect
                                // Check if the registration is pending or rejected
                                DatabaseReference statusReference = FirebaseDatabase.getInstance().getReference("requests").child("patientRegRequests");
                                statusReference.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        isPatientFound = false;

                                        // Patient registration request exists, check the status
                                        for (DataSnapshot requestSnapshot : dataSnapshot.getChildren()) {
                                            String registrationStatus = requestSnapshot.child("status").getValue(String.class);
                                            String patientEmail = requestSnapshot.child("email").getValue(String.class);
                                            String patientPassword = requestSnapshot.child("password").getValue(String.class);

                                            if (email.equals(patientEmail) && password.equals(patientPassword)) {
                                                isPatientFound = true;
                                            }

                                                if (isPatientFound && ("Pending".equals(registrationStatus) || "pending".equals(registrationStatus))) {
                                                    // Registration is pending, show the pending registration page
                                                    Intent pendingIntent = new Intent(LoginPatientActivity.this, PendingRegistration.class);
                                                    startActivity(pendingIntent);
                                                    return;
                                                } else {
                                                    DatabaseReference statusReference2 = FirebaseDatabase.getInstance().getReference("rejected").child("rejectedPatients");
                                                    statusReference2.addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot3) {
                                                            isPatientFound = false;

                                                            // Patient registration request exists, check the status
                                                            for (DataSnapshot requestSnapshot2 : dataSnapshot3.getChildren()) {
                                                                String registrationStatus = requestSnapshot2.child("status").getValue(String.class);
                                                                String patientEmail = requestSnapshot2.child("email").getValue(String.class);
                                                                String patientPassword = requestSnapshot2.child("password").getValue(String.class);

                                                                if (email.equals(patientEmail) && password.equals(patientPassword)) {
                                                                    isPatientFound = true;
                                                                }
                                                                    if (isPatientFound && ("rejected".equals(registrationStatus) || "Rejected".equals(registrationStatus))) {
                                                                        // Registration is rejected, show the rejected registration page
                                                                        Intent rejectedIntent = new Intent(LoginPatientActivity.this, RejectionActivity.class);
                                                                        startActivity(rejectedIntent);
                                                                        return;
                                                                    }
                                                                }
                                                            if (!isPatientFound) {
                                                                // No registration request found, handle it as needed
                                                                Toast.makeText(LoginPatientActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                                                            }
                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError databaseError2) {
                                                            // Handle errors
                                                        }
                                                    });
                                                }
                                            }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        // Handle errors
                                    }
                                });
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            // Handle errors
                        }
                    });
                }
            }
        });
    }

    private boolean validateFields() {
        boolean isValid = true;
        if (emailEditText.getText().toString().trim().isEmpty()) {
            emailEditText.setError("Email cannot be empty");
            isValid = false;
        } else {
            emailEditText.setError(null);
        }
        if (passwordEditText.getText().toString().trim().isEmpty()) {
            passwordEditText.setError("Password cannot be empty");
            isValid = false;
        } else {
            passwordEditText.setError(null);
        }
        return isValid;
    }
}
