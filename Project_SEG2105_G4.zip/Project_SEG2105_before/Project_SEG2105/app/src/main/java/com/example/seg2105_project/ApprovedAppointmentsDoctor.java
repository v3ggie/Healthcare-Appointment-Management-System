package com.example.seg2105_project;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class ApprovedAppointmentsDoctor extends AppCompatActivity {
    private LinearLayout containerLayout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_approved_appointments_doctor);

        containerLayout = findViewById(R.id.containerLayout);

        String employeeNumber = getIntent().getStringExtra("employeeNumber");

        searchAppointments(employeeNumber);
    }

    public void searchAppointments(String employeeNumber){
        containerLayout.removeAllViews();
        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Appointments").child("approved");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Date currentDate = Calendar.getInstance().getTime();
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    String formattedCurrentDate = dateFormat.format(currentDate);

                    for (DataSnapshot healthCardSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot appointmentSnapshot : healthCardSnapshot.getChildren()) {
                            String doctorEmployeeNumber = appointmentSnapshot.child("doctorEmployeeNumber").getValue(String.class);
                            String dateCheck = appointmentSnapshot.child("date").getValue(String.class);

                            if (employeeNumber.equals(doctorEmployeeNumber) && isFutureDate(dateCheck, formattedCurrentDate)) {
                                String patientName = appointmentSnapshot.child("patientName").getValue(String.class);
                                String date = appointmentSnapshot.child("date").getValue(String.class);
                                String time = appointmentSnapshot.child("time").getValue(String.class);
                                String appointmentId = appointmentSnapshot.child("appointmentId").getValue(String.class);
                                String patientId = appointmentSnapshot.child("healthCard").getValue(String.class);
                                String email = appointmentSnapshot.child("email").getValue(String.class);
                                String address = appointmentSnapshot.child("address").getValue(String.class);
                                String phoneNumber = appointmentSnapshot.child("phoneNumber").getValue(String.class);
                                String doctorId = appointmentSnapshot.child("doctorId").getValue(String.class);


                                if (appointmentId != null && patientName != null && doctorId != null && date != null && time != null && patientId != null && email != null && address != null && phoneNumber != null) {
                                    LinearLayout appointmentLayout = new LinearLayout(ApprovedAppointmentsDoctor.this);
                                    appointmentLayout.setOrientation(LinearLayout.VERTICAL);

                                    TextView textView = new TextView(ApprovedAppointmentsDoctor.this);
                                    textView.setText(String.format("Doctor: %s\nTime: %s\nDate: %s\n" +
                                                    "Patient Name: %s\nHealth Card: %s\nPatient Email: %s\n" +
                                                    "Patient Address: %s\nPatient Phone Number: %s\n" +
                                                    "Appointment ID: %s\nPatient ID: %s\n",
                                            doctorId, time, date, patientName, patientId, email, address, phoneNumber, appointmentId, patientId));
                                    textView.setTextColor(getResources().getColor(android.R.color.white));
                                    textView.setBackgroundResource(R.drawable.textview_background);
                                    LinearLayout.LayoutParams textLayoutParams = new LinearLayout.LayoutParams(
                                            LinearLayout.LayoutParams.MATCH_PARENT,
                                            LinearLayout.LayoutParams.WRAP_CONTENT
                                    );
                                    textView.setLayoutParams(textLayoutParams);
                                    int paddingValueInDp = 14;
                                    int paddingValueInPixels = (int) (paddingValueInDp * getResources().getDisplayMetrics().density);
                                    textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);

                                    Button cancelButton = new Button(ApprovedAppointmentsDoctor.this);
                                    cancelButton.setText("Cancel");

                                    cancelButton.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            cancelAppointment(patientId, appointmentId);
                                            containerLayout.removeView(appointmentLayout);
                                        }
                                    });

                                    appointmentLayout.addView(textView);
                                    appointmentLayout.addView(cancelButton);
                                    containerLayout.addView(appointmentLayout);
                                }
                            }
                        }
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void cancelAppointment(String healthCardNumber,String appointmentId) {
        try {
            // removes appointments from the Appointments node
            DatabaseReference appointmentsRef = FirebaseDatabase.getInstance()
                    .getReference("Appointments")
                    .child("approved")
                    .child(healthCardNumber)
                    .child(appointmentId);
            appointmentsRef.removeValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void goBack(View view) {
        Intent intent = new Intent(this, MenuDoctor.class);
        String employeeNumber = getIntent().getStringExtra("employeeNumber");
        intent.putExtra("employeeNumber", employeeNumber);
        String email = getIntent().getStringExtra("email");
        intent.putExtra("email", email);
        startActivity(intent);
    }

    private boolean isFutureDate(String appointmentDate, String currentDate) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
            Date date1 = dateFormat.parse(appointmentDate);
            Date date2 = dateFormat.parse(currentDate);

            return date1 != null && date1.after(date2);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}


