package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        String confirmationMessage = getIntent().getStringExtra("confirmationMessage");

        TextView confirmationTextView = findViewById(R.id.confirmationMessage);
        if (confirmationMessage != null && !confirmationMessage.isEmpty()) {
            confirmationTextView.setText(confirmationMessage);
        } else {
            confirmationTextView.setText("Appointment booked successfully!");
        }

        Button logoutButton = findViewById(R.id.logoutButton);
        Button backButton = findViewById(R.id.backButton);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToMenu();
            }
        });
    }

    public void logout() {
        Intent intent = new Intent(this, RoleSelectionActivity.class);
        startActivity(intent);
    }

    public void backToMenu() {
        Intent intent = new Intent(this, MenuPatient.class);
        String email = getIntent().getStringExtra("email");
        String healthCard = getIntent().getStringExtra("healthCard");
        intent.putExtra("healthCard", healthCard);
        intent.putExtra("email", email);
        startActivity(intent);
    }
}
