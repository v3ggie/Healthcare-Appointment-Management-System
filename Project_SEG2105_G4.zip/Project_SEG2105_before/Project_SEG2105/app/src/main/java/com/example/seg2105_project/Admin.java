package com.example.hams_test;

import android.app.Activity;
import android.widget.TextView;
import android.widget.LinearLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class Admin extends Activity {
    private String email;
    private String password;

    /**
     * Constructor for Admin class.
     *
     * @param email    Admin email address.
     * @param password Admin password.
     */
    public Admin(String email, String password) {
        this.email = "admin@hams.com";
        this.password = "AdminHams123!";
    }

    public Admin() {
    }

    /**
     * Accepts a patient registration request, removing it from the "requests/patientRegRequests" node,
     * and adds the patient to the "accepted/acceptedPatients" node in the Firebase Realtime Database.
     *
     * @param patient The patient object representing the registration request.
     */
    public void acceptPatient(Patient patient) {
        try {
            DatabaseReference patientRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("patientRegRequests")
                    .child(patient.getEmail().replace(".", ","));
            patientRegRequestsRef.removeValue();

            DatabaseReference acceptedPatientsRef = FirebaseDatabase.getInstance()
                    .getReference("accepted")
                    .child("acceptedPatients")
                    .child(patient.getEmail().replace(".", ","));

            acceptedPatientsRef.setValue(patient);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Rejects a patient registration request, removing it from the "requests/patientRegRequests" node,
     * and adds the patient to the "rejected/rejectedPatients" node in the Firebase Realtime Database.
     *
     * @param patient The patient object representing the registration request.
     */
    public void rejectPatient(Patient patient) {
        try {
            DatabaseReference patientRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("patientRegRequests")
                    .child(patient.getEmail().replace(".", ","));
            patientRegRequestsRef.removeValue();

            DatabaseReference rejectedPatientsRef = FirebaseDatabase.getInstance()
                    .getReference("rejected")
                    .child("rejectedPatients")
                    .child(patient.getEmail().replace(".", ","));

            rejectedPatientsRef.setValue(patient);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void acceptDoctor(Doctor doctor) {
        try {
            DatabaseReference doctorRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("doctorRegRequests")
                    .child(doctor.getEmail().replace(".", ","));
            doctorRegRequestsRef.removeValue();

            DatabaseReference acceptedDoctorsRef = FirebaseDatabase.getInstance()
                    .getReference("accepted")
                    .child("acceptedDoctors")
                    .child(doctor.getEmail().replace(".", ","));

            acceptedDoctorsRef.setValue(doctor);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void rejectDoctor(Doctor doctor) {
        try {
            DatabaseReference doctorRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("doctorRegRequests")
                    .child(doctor.getEmail().replace(".", ","));
            doctorRegRequestsRef.removeValue();

            DatabaseReference rejectedDoctorsRef = FirebaseDatabase.getInstance()
                    .getReference("rejected")
                    .child("rejectedDoctors")
                    .child(doctor.getEmail().replace(".", ","));

            rejectedDoctorsRef.setValue(doctor);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Retrieves and displays information about rejected patients from the "rejected/rejectedPatients" node
     * in the Firebase Realtime Database. Displays the information in a TextView added to the provided
     * LinearLayout containerLayout.
     *
     * @param containerLayout The layout where the information about rejected patients will be displayed.
     */
    public void viewRejectedPatients(LinearLayout containerLayout) {
        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("rejected").child("rejectedPatients");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot patientSnapshot : dataSnapshot.getChildren()) {
                        String firstName = patientSnapshot.child("firstName").getValue(String.class);
                        String lastName = patientSnapshot.child("lastName").getValue(String.class);
                        String email = patientSnapshot.child("email").getValue(String.class);
                        String phone = patientSnapshot.child("phone").getValue(String.class);
                        String status = patientSnapshot.child("status").getValue(String.class);

                        if (firstName != null && lastName != null && email != null && phone != null && status != null) {
                            TextView textView = new TextView(containerLayout.getContext());
                            textView.setText(String.format("Name: %s %s\nEmail: %s\nPhone: %s\nStatus: %s",
                                    firstName, lastName, email, phone, status));
                            textView.setTextColor(containerLayout.getResources().getColor(android.R.color.white));
                            textView.setBackgroundResource(R.drawable.textview_background);
                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT
                            );
                            layoutParams.setMargins(0, 0, 0, 16);
                            textView.setLayoutParams(layoutParams);
                            int paddingValueInDp = 14;
                            int paddingValueInPixels = (int) (paddingValueInDp * containerLayout.getResources().getDisplayMetrics().density);
                            textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);

                            containerLayout.addView(textView);
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Retrieves and displays information about rejected doctors from the "rejected/rejectedDoctors" node
     * in the Firebase Realtime Database. Displays the information in a TextView added to the provided
     * LinearLayout containerLayout.
     *
     * @param containerLayout The layout where the information about rejected doctors will be displayed.
     */
    public void viewRejectedDoctors(LinearLayout containerLayout) {
        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("rejected").child("rejectedDoctors");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot doctorSnapshot : dataSnapshot.getChildren()) {
                        String firstName = doctorSnapshot.child("firstName").getValue(String.class);
                        String lastName = doctorSnapshot.child("lastName").getValue(String.class);
                        String email = doctorSnapshot.child("email").getValue(String.class);
                        String phone = doctorSnapshot.child("phone").getValue(String.class);
                        String status = doctorSnapshot.child("status").getValue(String.class);

                        if (firstName != null && lastName != null && email != null && phone != null && status != null) {
                            TextView textView = new TextView(containerLayout.getContext());
                            textView.setText(String.format("Name: %s %s\nEmail: %s\nPhone: %s\nStatus: %s",
                                    firstName, lastName, email, phone, status));
                            textView.setTextColor(containerLayout.getResources().getColor(android.R.color.white));
                            textView.setBackgroundResource(R.drawable.textview_background);
                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT
                            );
                            layoutParams.setMargins(0, 0, 0, 16);
                            textView.setLayoutParams(layoutParams);
                            int paddingValueInDp = 14;
                            int paddingValueInPixels = (int) (paddingValueInDp * containerLayout.getResources().getDisplayMetrics().density);
                            textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);

                            containerLayout.addView(textView);
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Prints information about rejected patients to the console.
     */
    public void printRejectedPatients() {
        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("rejected").child("rejectedPatients");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot patientSnapshot : dataSnapshot.getChildren()) {
                        String firstName = patientSnapshot.child("firstName").getValue(String.class);
                        String lastName = patientSnapshot.child("lastName").getValue(String.class);
                        String email = patientSnapshot.child("email").getValue(String.class);
                        String phone = patientSnapshot.child("phone").getValue(String.class);
                        String status = patientSnapshot.child("status").getValue(String.class);

                        if (firstName != null && lastName != null && email != null && phone != null && status != null) {
                            System.out.println(String.format("Rejected Patient: Name: %s %s, Email: %s, Phone: %s, Status: %s",
                                    firstName, lastName, email, phone, status));
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Prints information about rejected doctors to the console.
     */
    public void printRejectedDoctors() {
        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("rejected").child("rejectedDoctors");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot doctorSnapshot : dataSnapshot.getChildren()) {
                        String firstName = doctorSnapshot.child("firstName").getValue(String.class);
                        String lastName = doctorSnapshot.child("lastName").getValue(String.class);
                        String email = doctorSnapshot.child("email").getValue(String.class);
                        String phone = doctorSnapshot.child("phone").getValue(String.class);
                        String status = doctorSnapshot.child("status").getValue(String.class);

                        if (firstName != null && lastName != null && email != null && phone != null && status != null) {
                            System.out.println(String.format("Rejected Doctor: Name: %s %s, Email: %s, Phone: %s, Status: %s",
                                    firstName, lastName, email, phone, status));
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Accepts a patient registration request.
     *
     * @param patient The patient object representing the registration request.
     * @return true if the operation is successful, false otherwise.
     */
    public boolean acceptedPatient(Patient patient) {
        try {
            DatabaseReference patientRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("patientRegRequests")
                    .child(patient.getEmail().replace(".", ","));
            patientRegRequestsRef.removeValue();

            DatabaseReference acceptedPatientsRef = FirebaseDatabase.getInstance()
                    .getReference("accepted")
                    .child("acceptedPatients")
                    .child(patient.getEmail().replace(".", ","));

            acceptedPatientsRef.setValue(patient);

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Rejects a patient registration request.
     *
     * @param patient The patient object representing the registration request.
     * @return true if the operation is successful, false otherwise.
     */
    public boolean rejectedPatient(Patient patient) {
        try {
            DatabaseReference patientRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("patientRegRequests")
                    .child(patient.getEmail().replace(".", ","));
            patientRegRequestsRef.removeValue();

            DatabaseReference rejectedPatientsRef = FirebaseDatabase.getInstance()
                    .getReference("rejected")
                    .child("rejectedPatients")
                    .child(patient.getEmail().replace(".", ","));

            rejectedPatientsRef.setValue(patient);

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Accepts a doctor registration request.
     *
     * @param doctor The doctor object representing the registration request.
     * @return true if the operation is successful, false otherwise.
     */
    public boolean acceptedDoctor(Doctor doctor) {
        try {
            DatabaseReference doctorRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("doctorRegRequests")
                    .child(doctor.getEmail().replace(".", ","));
            doctorRegRequestsRef.removeValue();

            DatabaseReference acceptedDoctorsRef = FirebaseDatabase.getInstance()
                    .getReference("accepted")
                    .child("acceptedDoctors")
                    .child(doctor.getEmail().replace(".", ","));

            acceptedDoctorsRef.setValue(doctor);

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Rejects a doctor registration request.
     *
     * @param doctor The doctor object representing the registration request.
     * @return true if the operation is successful, false otherwise.
     */
    public boolean rejectedDoctor(Doctor doctor) {
        try {
            DatabaseReference doctorRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("doctorRegRequests")
                    .child(doctor.getEmail().replace(".", ","));
            doctorRegRequestsRef.removeValue();

            DatabaseReference rejectedDoctorsRef = FirebaseDatabase.getInstance()
                    .getReference("rejected")
                    .child("rejectedDoctors")
                    .child(doctor.getEmail().replace(".", ","));

            rejectedDoctorsRef.setValue(doctor);

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
