package com.example.seg2105_project;

public interface AppointmentsCallback {
    void onAppointmentsChecked(boolean hasLinkedAppointments);
}
