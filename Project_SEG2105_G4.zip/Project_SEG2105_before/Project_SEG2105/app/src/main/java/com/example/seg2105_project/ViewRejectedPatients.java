package com.example.seg2105_project;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class ViewRejectedPatients extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_rejected_patients);
        LinearLayout containerLayout = findViewById(R.id.containerP);

        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("rejected").child("rejectedPatients");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot patientSnapshot : dataSnapshot.getChildren()) {
                        String firstName = patientSnapshot.child("firstName").getValue(String.class);
                        String lastName = patientSnapshot.child("lastName").getValue(String.class);
                        String email = patientSnapshot.child("email").getValue(String.class);
                        String phone = patientSnapshot.child("phone").getValue(String.class);
                        String status = patientSnapshot.child("status").getValue(String.class);

                        if (firstName != null && lastName != null && email != null && phone != null && status != null) {
                            LinearLayout patientLayout = new LinearLayout(ViewRejectedPatients.this);
                            patientLayout.setOrientation(LinearLayout.VERTICAL);  // Change to VERTICAL

                            TextView textView = new TextView(ViewRejectedPatients.this);
                            textView.setText(String.format("Name: %s %s\nEmail: %s\nPhone: %s\nStatus: %s",
                                    firstName, lastName, email, phone, status));
                            textView.setTextColor(getResources().getColor(android.R.color.white));
                            textView.setBackgroundResource(R.drawable.textview_background);
                            LinearLayout.LayoutParams textLayoutParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT
                            );
                            textView.setLayoutParams(textLayoutParams);
                            int paddingValueInDp = 14;
                            int paddingValueInPixels = (int) (paddingValueInDp * getResources().getDisplayMetrics().density);
                            textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);


                            Button acceptButton = new Button(ViewRejectedPatients.this);
                            acceptButton.setText("Accept");
                            Button rejectButton = new Button(ViewRejectedPatients.this);
                            rejectButton.setText("Reject");


                            acceptButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    acceptPatient(patientSnapshot);
                                    containerLayout.removeView(patientLayout);
                                }
                            });
                            patientLayout.addView(textView);
                            patientLayout.addView(acceptButton);
                            containerLayout.addView(patientLayout);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void acceptPatient(DataSnapshot patientSnapshot) {
        try {
            // Get details
            String healthCard = patientSnapshot.child("healthCard").getValue(String.class);

            // new map for accepted patients
            Map<String, Object> acceptedPatient = new HashMap<>();
            acceptedPatient.put("email", patientSnapshot.child("email").getValue(String.class));
            acceptedPatient.put("firstName", patientSnapshot.child("firstName").getValue(String.class));
            acceptedPatient.put("lastName", patientSnapshot.child("lastName").getValue(String.class));
            acceptedPatient.put("address", patientSnapshot.child("address").getValue(String.class));
            acceptedPatient.put("phone", patientSnapshot.child("phone").getValue(String.class));
            acceptedPatient.put("healthCard", healthCard);
            acceptedPatient.put("password", patientSnapshot.child("password").getValue(String.class));
            acceptedPatient.put("status", "accepted"); // Set status to "accepted"

            // removes patient from patientRegRequests
            DatabaseReference patientRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("patientRegRequests")
                    .child(healthCard); // Firebase doesn't allow dots in keys
            patientRegRequestsRef.removeValue();

            // adds patient to acceptedPatients
            DatabaseReference acceptedPatientsRef = FirebaseDatabase.getInstance()
                    .getReference("accepted")
                    .child("acceptedPatients")
                    .child(healthCard); // Firebase doesn't allow dots in keys
            acceptedPatientsRef.setValue(acceptedPatient);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onClickBack(View view) {
        Intent intent = new Intent(this, MenuAdminRejectedSelection.class);
        startActivity(intent);
    }
}
