package com.example.seg2105_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class DoctorRegistration extends AppCompatActivity {

    private EditText firstNameEditText;
    private EditText lastNameEditText;
    private EditText emailEditText;
    private EditText passwordEditText;
    private EditText phoneEditText;
    private EditText addressEditText;
    private EditText employeeNumberEditText;
    private CheckBox specialtyFamilyMedicine;
    private CheckBox specialtyInternalMedicine;
    private CheckBox specialtyPediatrics;
    private CheckBox specialtyObstetricsGynecology;
    private CheckBox specialtyOther;
    private EditText otherSpecialtyEditText;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_doctor);

        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        addressEditText = findViewById(R.id.addressEditText);
        employeeNumberEditText = findViewById(R.id.employeeNumberEditText);
        specialtyFamilyMedicine = findViewById(R.id.specialtyFamilyMedicine);
        specialtyInternalMedicine = findViewById(R.id.specialtyInternalMedicine);
        specialtyPediatrics = findViewById(R.id.specialtyPediatrics);
        specialtyObstetricsGynecology = findViewById(R.id.specialtyObstetricsGynecology);
        specialtyOther = findViewById(R.id.specialtyOther);
        otherSpecialtyEditText = findViewById(R.id.otherSpecialtyEditText);

        databaseReference = FirebaseDatabase.getInstance().getReference("requests");
    }

    public void onRegisterClick(View view) {
        if (validateFields()) {
            Doctor doctor = new Doctor(
                    firstNameEditText.getText().toString(),
                    lastNameEditText.getText().toString(),
                    emailEditText.getText().toString(),
                    passwordEditText.getText().toString(),
                    phoneEditText.getText().toString(),
                    addressEditText.getText().toString(),
                    employeeNumberEditText.getText().toString(),
                    getSelectedSpecialties(),
                    "pending");


            String key = encodeIdAsKey(doctor.getEmployeeNumber());
            doctor.setKey(key);

            DatabaseReference doctorsRef = databaseReference.child("doctorRegRequests").child(key);


            doctorsRef.child("status").setValue(doctor.getStatus());
            doctorsRef.child("firstName").setValue(doctor.getFirstName());
            doctorsRef.child("lastName").setValue(doctor.getLastName());
            doctorsRef.child("email").setValue(doctor.getEmail());
            doctorsRef.child("password").setValue(doctor.getPassword());
            doctorsRef.child("employeeNumber").setValue(doctor.getEmployeeNumber());
            doctorsRef.child("specialty").setValue(doctor.getSpecialties());
            doctorsRef.child("phone").setValue(doctor.getPhone());

//            // Saves the Dr object to the database
//            String key = encodeEmailAsKey(doctor.getEmail());
//            DatabaseReference doctorsRef = databaseReference.child("doctorRegRequests").child(key);
//            doctorsRef.setValue(doctor);

            Intent intent = new Intent(DoctorRegistration.this, PendingRegistration.class);
            startActivity(intent);
            finish();
        }
    }

    private List<String> getSelectedSpecialties() {
        List<String> selectedSpecialties = new ArrayList<>();

        if (specialtyFamilyMedicine.isChecked()) {
            selectedSpecialties.add("Family Medicine");
        }
        if (specialtyInternalMedicine.isChecked()) {
            selectedSpecialties.add("Internal Medicine");
        }
        if (specialtyPediatrics.isChecked()) {
            selectedSpecialties.add("Pediatrics");
        }
        if (specialtyObstetricsGynecology.isChecked()) {
            selectedSpecialties.add("Obstetrics and Gynecology");
        }
        if (specialtyOther.isChecked()) {
            String otherSpecialty = otherSpecialtyEditText.getText().toString().trim();
            if (!otherSpecialty.isEmpty()) {
                selectedSpecialties.add(otherSpecialty);
            }
        }

        return selectedSpecialties;
    }
    private String encodeIdAsKey(String employeeNumber) {
        return employeeNumber;
    }


    private boolean validateFields() {
        boolean isValid = true;
        if (!validateFirstName(firstNameEditText, "First Name")) isValid = false;
        if (!validateLastName(lastNameEditText, "Last Name")) isValid = false;
        if (!validateEmail(emailEditText)) isValid = false;
        if (!validatePassword(passwordEditText)) isValid = false;
        if (!validatePhoneNumber(phoneEditText)) isValid = false;
        if (!validateField(addressEditText, "Address")) isValid = false;
        if (!validateEmployeeNumber(employeeNumberEditText)) isValid = false;
        if (!validateSpecialties()) isValid = false;
        return isValid;
    }

    private boolean validateSpecialties() {
        boolean atLeastOneSpecialtyChecked = specialtyFamilyMedicine.isChecked() || specialtyInternalMedicine.isChecked() ||
                specialtyPediatrics.isChecked() || specialtyObstetricsGynecology.isChecked() || specialtyOther.isChecked();

        if (!atLeastOneSpecialtyChecked) {
            otherSpecialtyEditText.setError("Specify 'Other' or select at least one specialty.");
            return false;
        }

        otherSpecialtyEditText.setError(null);
        return true;
    }

    private boolean validateFirstName(EditText editText, String fieldName) {
        String fieldValue = editText.getText().toString().trim();
        if (fieldValue.isEmpty()) {
            editText.setError(fieldName + " cannot be empty");
            return false;
        } else if (!fieldValue.matches("^[a-zA-Z]+$")) {
            editText.setError(fieldName + " must contain only letters");
            return false;
        }
        editText.setError(null);
        return true;
    }

    private boolean validateLastName(EditText editText, String fieldName) {
        String fieldValue = editText.getText().toString().trim();
        if (fieldValue.isEmpty()) {
            editText.setError(fieldName + " cannot be empty");
            return false;
        } else if (!fieldValue.matches("^[a-zA-Z]+$")) {
            editText.setError(fieldName + " must contain only letters");
            return false;
        }
        editText.setError(null);
        return true;
    }

    private boolean validateField(EditText editText, String fieldName) {
        String fieldValue = editText.getText().toString().trim();
        if (fieldValue.isEmpty()) {
            editText.setError(fieldName + " cannot be empty");
            return false;
        }
        editText.setError(null);
        return true;
    }

    private boolean validateEmail(EditText emailEditText) {
        String email = emailEditText.getText().toString().trim();
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.setError("Enter a valid email address");
            return false;
        }
        emailEditText.setError(null);
        return true;
    }

    private boolean validatePassword(EditText passwordEditText) {
        String password = passwordEditText.getText().toString().trim();
        if (password.isEmpty() || !password.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,}$")) {
            passwordEditText.setError("Password must contain at least 1 digit, 1 lowercase, 1 uppercase letter, and be at least 6 characters long.");
            return false;
        }
        passwordEditText.setError(null);
        return true;
    }

    private boolean validatePhoneNumber(EditText phoneEditText) {
        String phoneNumber = phoneEditText.getText().toString().trim();
        if (phoneNumber.isEmpty() || !phoneNumber.matches("^[0-9]+$")) {
            phoneEditText.setError("Enter a valid phone number");
            return false;
        }
        phoneEditText.setError(null);
        return true;
    }

    private boolean validateEmployeeNumber(EditText employeeNumberEditText) {
        String employeeNumber = employeeNumberEditText.getText().toString().trim();
        if (employeeNumber.isEmpty()) {
            employeeNumberEditText.setError("Employee Number cannot be empty");
            return false;
        }
        employeeNumberEditText.setError(null);
        return true;
    }

    public boolean addDoctorToDatabase(DatabaseReference databaseReference, Doctor doctor) {
        try {
            databaseReference.child("doctorRegRequests").child(doctor.getKey()).setValue(doctor);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean addDoctorsToDatabase(DatabaseReference databaseReference, Doctor doctor) {
        if (doctor != null) {
            String key = encodeEmailAsKey(doctor.getEmail());

            doctor.setKey(key);

            DatabaseReference doctorsRef = databaseReference.child("doctorRegRequests").child(key);

            doctorsRef.child("status").setValue(doctor.getStatus());
            doctorsRef.child("firstName").setValue(doctor.getFirstName());
            doctorsRef.child("lastName").setValue(doctor.getLastName());
            doctorsRef.child("email").setValue(doctor.getEmail());
            doctorsRef.child("password").setValue(doctor.getPassword());
            doctorsRef.child("employeeNumber").setValue(doctor.getEmployeeNumber());
            doctorsRef.child("specialty").setValue(doctor.getSpecialties());
            doctorsRef.child("phone").setValue(doctor.getPhone());
            doctorsRef.child("shifts").setValue(null);

            return true;
        }
        return false; // not added to the database
    }
}