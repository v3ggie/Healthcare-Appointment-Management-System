package com.example.seg2105_project;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class RoleSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_role_selection);

        Button patientButton = findViewById(R.id.patientButton);
        Button doctorButton = findViewById(R.id.doctorButton);
        Button adminButton = findViewById(R.id.adminButton);

        doctorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String role = "Doctor";
                Intent intent = new Intent(RoleSelectionActivity.this, LoginDoctorActivity.class);
                intent.putExtra("role", role);
                startActivity(intent);
            }
        });

        patientButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String role = "Patient";
                Intent intent = new Intent(RoleSelectionActivity.this, LoginPatientActivity.class);
                intent.putExtra("role", role);
                startActivity(intent);
            }
        });

        adminButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RoleSelectionActivity.this, LoginAdminActivity.class);
                startActivity(intent);
            }
        });
    }

}
