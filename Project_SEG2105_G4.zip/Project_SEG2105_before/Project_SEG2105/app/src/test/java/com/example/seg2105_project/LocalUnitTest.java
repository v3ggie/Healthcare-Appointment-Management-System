package com.example.seg2105_project;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import org.junit.Test;
import androidx.appcompat.app.AppCompatActivity;
import static org.junit.Assert.assertTrue;
import java.util.ArrayList;

public class LocalUnitTest {
    private DatabaseReference databaseReference;

    /**
     * Unit test for the PatientRegistration class.
     * Verifies that a patient is successfully added to the Database.
     */
    @Test
    public void testPatientRegistration() {
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("testRequests").child("patients");
        PatientRegistration patientRegistration = new PatientRegistration();
        Patient patient = createMockPatient("John", "Doe", "john.doe@example.com",
                "Password123", "1234567890", "123 Bank Street", "123456789");

        boolean isPatientAdded = patientRegistration.addPatientsToDatabase(databaseReference, patient);
        assertTrue(isPatientAdded);
    }

    /**
     * Unit test for the DoctorRegistration class.
     * Verifies that a doctor is successfully added to the Database.
     */
    @Test
    public void testDoctorRegistration() {
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("testRequests").child("doctors");
        DoctorRegistration doctorRegistration = new DoctorRegistration();

        Doctor doctor = createMockDoctor(
                "John",
                "Doe",
                "john.doe.doctor@example.com",
                "Password123",
                "1234567890",
                "123 Bank Street",
                "98765432"
        );

        boolean isDoctorAdded = doctorRegistration.addDoctorsToDatabase(databaseReference, doctor);
        assertTrue(isDoctorAdded);
    }


    /**
     * Unit test for admin accepting a patient.
     * Verifies that an admin with valid credentials can accept a patient.
     */
    @Test
    public void testAdminAcceptPatient() {
        Admin admin = new Admin();

        Patient patient = createMockPatient("John", "Doe", "john.doe@example.com",
                "Password123", "1234567890", "123 Bank Street", "123456789");

        admin.acceptPatient(patient);
        boolean isPatientAccepted = admin.acceptedPatient(patient);
        assertTrue(isPatientAccepted);
    }

    /**
     * Unit test for admin rejecting a patient.
     * Verifies that an admin with valid credentials can reject a patient.
     */
    @Test
    public void testAdminRejectPatient() {
        Admin admin = new Admin("admin@hams.com", "AdminHams123!"); // Use valid admin credentials

        Patient patient = createMockPatient("John", "Doe", "john.doe@example.com",
                "Password123", "1234567890", "123 Main Street", "123456789");

        admin.rejectPatient(patient);
        boolean isPatientRejected = admin.rejectedPatient(patient);
        assertTrue(isPatientRejected);
    }

    /**
     * Unit test for admin accepting a doctor.
     * Verifies that an admin with valid credentials can accept a doctor.
     */
    @Test
    public void testAdminAcceptDoctor() {
        Admin admin = new Admin("admin@hams.com", "AdminHams123!"); // Use valid admin credentials

        Doctor doctor = createMockDoctor(
                "John",
                "Doe",
                "john.doe.doctor@example.com",
                "Password123",
                "1234567890",
                "123 Bank Street",
                "98765432"
        );
        admin.acceptDoctor(doctor);
        boolean isDoctorAccepted = admin.acceptedDoctor(doctor);
        assertTrue(isDoctorAccepted);
    }

    /**
     * Unit test for admin rejecting a doctor.
     * Verifies that an admin with valid credentials can reject a doctor.
     */
    @Test
    public void testAdminRejectDoctor() {
        Admin admin = new Admin("admin@hams.com", "AdminHams123!"); // Use valid admin credentials

        Doctor doctor = createMockDoctor(
                "John",
                "Doe",
                "john.doe.doctor@example.com",
                "Password123",
                "1234567890",
                "123 Bank Street",
                "98765432"
        );
        admin.rejectDoctor(doctor);
        boolean isDoctorRejected = admin.rejectedDoctor(doctor);
        assertTrue(isDoctorRejected);
    }


    /**
     *
     * HELPER METHODS BELOW
     */



    /**
     * Creates a mock Doctor object for testing purposes.
     * @param firstName       First name of the doctor.
     * @param lastName        Last name of the doctor.
     * @param email           Email of the doctor.
     * @param password        Password of the doctor.
     * @param phone           Phone number of the doctor.
     * @param address         Address of the doctor.
     * @param employeeNumber  Employee number of the doctor.
     * @return                The created mock Doctor object.
     */
    private Doctor createMockDoctor(String firstName, String lastName, String email,
                                    String password, String phone, String address, String employeeNumber) {
        return new Doctor(firstName, lastName, email, password, phone, address, employeeNumber, new ArrayList<>(),
                "pending");
    }

    /**
     * Creates a mock Patient object for testing purposes.
     * @param firstName    First name of the patient.
     * @param lastName     Last name of the patient.
     * @param email        Email of the patient.
     * @param password     Password of the patient.
     * @param phone        Phone number of the patient.
     * @param address      Address of the patient.
     * @param healthCard   Health card number of the patient.
     * @return             The created mock Patient object.
     */
    private Patient createMockPatient(String firstName, String lastName, String email,
                                      String password, String phone, String address, String healthCard) {
        return new Patient(firstName, lastName, email, password, phone, address, healthCard, "Pending");
    }

    /**
     * Encodes the name as a key by combining the first name and last name.
     * @param firstName  First name of the person.
     * @param lastName   Last name of the person.
     * @return           The encoded name key.
     */
    String encodeNameAsKey(String firstName, String lastName) {
        return firstName + " " + lastName;
    }
}
