package com.example.hams_test;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ShiftCreate extends AppCompatActivity {

    private Spinner startTimeSpinner;
    private Spinner endTimeSpinner;
    private DatePicker datePicker;
    private Button createShiftButton;
    private Button deleteShiftButton;
    private TextView shiftDetailsTextView;
    private EditText employeeNumberEditText; // Added EditText for employee number

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_shift);

        startTimeSpinner = findViewById(R.id.startTimeSpinner);
        endTimeSpinner = findViewById(R.id.endTimeSpinner);
        datePicker = findViewById(R.id.datePicker);
        createShiftButton = findViewById(R.id.createShiftButton);
        deleteShiftButton = findViewById(R.id.deleteShiftButton);
        shiftDetailsTextView = findViewById(R.id.shiftDetailsTextView);
        employeeNumberEditText = findViewById(R.id.employeeNumberEditText); // Initialize EditText

        createShiftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createShift();
            }
        });
    }
        deleteShiftButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            deleteShift();
        }
    });
}

    private void createShift() {
        String startTime = startTimeSpinner.getSelectedItem().toString();
        String endTime = endTimeSpinner.getSelectedItem().toString();
        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth() + 1;

        String employeeNumber = employeeNumberEditText.getText().toString();

        if (employeeNumber.isEmpty()) {
            Toast.makeText(this, "Please enter Employee Number", Toast.LENGTH_SHORT).show();
            return;
        }

        Shift shift = new Shift(startTime, endTime, day, month, employeeNumber);

        // Adds shift to the DB
        updateShiftsInDatabase(shift);
        Toast.makeText(this, "Shift created successfully", Toast.LENGTH_LONG).show();
        updateShiftDetailsTextView(shift);
    }

    private void deleteShift() {
        String employeeNumber = employeeNumberEditText.getText().toString().trim();

        if (employeeNumber.isEmpty()) {
            Toast.makeText(this, "Please enter Employee Number", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference shiftsRef = FirebaseDatabase.getInstance().getReference("Shifts");

        shiftsRef.child(employeeNumber).removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(ShiftCreate.this, "Shift deleted successfully", Toast.LENGTH_SHORT).show();
                        clearShiftDetails();  // Clear shift details TextView after deletion
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(ShiftCreate.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void clearShiftDetails() {
        // Clear shift details TextView
        shiftDetailsTextView.setText("");
    }

    private void updateShiftDetailsTextView(Shift shift) {
        String shiftDetails = "Date: " + shift.getDay() + "/" + shift.getMonth() +
                "\nStart Time: " + shift.getStartTime() +
                "\nEnd Time: " + shift.getEndTime() +
                "\nEmployee Number: " + shift.getEmployeeNumber();
        shiftDetailsTextView.setText(shiftDetails);
    }

    private void updateShiftsInDatabase(Shift shift) {
        try {
            DatabaseReference shiftsRef = FirebaseDatabase.getInstance().getReference("Shifts");

            // employee number = key for the shift
            shiftsRef.child(shift.getEmployeeNumber()).setValue(shift);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
