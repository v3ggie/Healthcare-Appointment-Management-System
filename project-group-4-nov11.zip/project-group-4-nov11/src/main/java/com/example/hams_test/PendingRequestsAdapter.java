// PendingRequestsAdapter.java
package com.example.hams_test;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PendingRequestsAdapter extends RecyclerView.Adapter<PendingRequestsAdapter.ViewHolder>  {

    private List<Patient> pendingRequests;

    public PendingRequestsAdapter(List<Patient> pendingRequests) {
        this.pendingRequests = pendingRequests;
    }

    public PendingRequestsAdapter() {
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pending_request, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Patient patient = pendingRequests.get(position);
        holder.bind(patient);
    }

    @Override
    public int getItemCount() {
        return pendingRequests.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView firstNameTextView;
        private TextView lastNameTextView;
        private TextView emailTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            firstNameTextView = itemView.findViewById(R.id.firstNameTextView);
            lastNameTextView = itemView.findViewById(R.id.lastNameTextView);
            emailTextView = itemView.findViewById(R.id.emailTextView);
        }

        public void bind(Patient patient) {
            firstNameTextView.setText(patient.getFirstName());
            lastNameTextView.setText(patient.getLastName());
            emailTextView.setText(patient.getEmail());
        }
    }
}
