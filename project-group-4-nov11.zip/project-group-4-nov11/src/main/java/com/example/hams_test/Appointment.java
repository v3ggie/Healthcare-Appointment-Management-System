package com.example.hams_test;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Appointment implements Serializable {
    private String appointmentId;
    private String patientName;
    private String date;
    private String time;
    private boolean approved;
    private String patientId;
    private String doctorId;

    // Constructors, getters, and setters go here

    // Example constructor
    public Appointment(String appointmentId, String patientName, String date, String time, boolean approved, String patientId, String doctorId) {
        this.appointmentId = appointmentId;
        this.patientName = patientName;
        this.date = date;
        this.time = time;
        this.approved = approved;
        this.patientId = patientId;
        this.doctorId = doctorId;
    }

    // Getters and setters for other fields

    // Example getters and setters
    public String getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }

    public String getDoctorId(){
        return doctorId;
    }

    public void setDoctorId(String doctorId){
        this.doctorId= doctorId;
    }

    public String getPatientName(){
        return patientName;
    }

    public void setPatientName(String patientName){
        this.patientName=patientName;
    }

    public String getDate(){
        return date;
    }

    public void setDate(String date){
        this.date=date;
    }

    public String getTime(){
        return time;
    }

    public void setTime(String time){
        this.time=time;
    }

    public String getPatientId(){
        return patientId;
    }

    public void setPatientId(String patientId){
        this.patientId=patientId;
    }

    public boolean isApproved() {
        return approved;
    }

    public void approveAppointment() {
        this.approved = true;
    }

    public void rejectAppointment() {
        this.approved = false;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }
    public String getPatientNameFromId(String patientId) {
        if (patientId.equals(this.patientId)) {
            return this.patientName;
        }
        return "Unknown Patient";
    }

    public boolean isPastAppointment() {
        try {
            // Assuming the date and time format is "yyyy-MM-dd HH:mm"
            String dateTimeString = getDate() + " " + getTime();
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            // Parse the appointment date and time
            Date appointmentDateTime = format.parse(dateTimeString);

            // Get the current date and time
            Date currentDateTime = new Date();

            // Compare the appointment date and time with the current date and time
            return appointmentDateTime.before(currentDateTime);
        } catch (ParseException e) {
            // Handle the exception, e.g., log it or return a default value
            e.printStackTrace();
            return false;
        }
    }
}