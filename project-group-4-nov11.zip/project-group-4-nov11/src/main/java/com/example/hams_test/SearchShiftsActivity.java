package com.example.hams_test;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class SearchShiftsActivity extends AppCompatActivity {

    private EditText employeeNumberEditText;
    private Button searchButton;
    private LinearLayout containerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_shifts);

        employeeNumberEditText = findViewById(R.id.employeeNumberEditText);
        searchButton = findViewById(R.id.searchButton);
        containerLayout = findViewById(R.id.containerLayout);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchShifts();
            }
        });
    }

    private void searchShifts() {
        String employeeNumber = employeeNumberEditText.getText().toString().trim();

        if (employeeNumber.isEmpty()) {
            Toast.makeText(this, "Please enter an employee number", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference shiftsRef = FirebaseDatabase.getInstance().getReference("Shifts");

        shiftsRef.orderByChild("employeeNumber").equalTo(employeeNumber)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        List<Shift> shiftsList = new ArrayList<>();

                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Shift shift = snapshot.getValue(Shift.class);
                            shiftsList.add(shift);
                            Log.d("FirebaseData", "Shift found: " + shift.getEmployeeNumber());
                        }

                        displayShifts(shiftsList);
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(SearchShiftsActivity.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private void displayShifts(List<Shift> shiftsList) {
        containerLayout.removeAllViews();

        if (!shiftsList.isEmpty()) {
            for (Shift shift : shiftsList) {
                TextView textView = new TextView(SearchShiftsActivity.this);
                textView.setText(String.format("Start Time: %s\nEnd Time: %s",
                        shift.getStartTime(), shift.getEndTime()));
                containerLayout.addView(textView);
            }
        } else {
            Toast.makeText(SearchShiftsActivity.this, "No shifts found for the entered employee number", Toast.LENGTH_SHORT).show();
        }
    }
}
