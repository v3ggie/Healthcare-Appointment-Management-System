package com.example.hams_test;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class ViewPendingPatients extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_pending_patients);
        LinearLayout containerLayout = findViewById(R.id.containerP);

        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("requests").child("patientRegRequests");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot patientSnapshot : dataSnapshot.getChildren()) {
                        String firstName = patientSnapshot.child("firstName").getValue(String.class);
                        String lastName = patientSnapshot.child("lastName").getValue(String.class);
                        String email = patientSnapshot.child("email").getValue(String.class);
                        String phone = patientSnapshot.child("phone").getValue(String.class);
                        String status = patientSnapshot.child("status").getValue(String.class);

                        if (firstName != null && lastName != null && email != null && phone != null && status != null) {
                            LinearLayout patientLayout = new LinearLayout(ViewPendingPatients.this);
                            patientLayout.setOrientation(LinearLayout.VERTICAL);  // Change to VERTICAL

                            TextView textView = new TextView(ViewPendingPatients.this);
                            textView.setText(String.format("Name: %s %s\nEmail: %s\nPhone: %s\nStatus: %s",
                                    firstName, lastName, email, phone, status));
                            textView.setTextColor(getResources().getColor(android.R.color.white));
                            textView.setBackgroundResource(R.drawable.textview_background);
                            LinearLayout.LayoutParams textLayoutParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT
                            );
                            textView.setLayoutParams(textLayoutParams);
                            int paddingValueInDp = 14;
                            int paddingValueInPixels = (int) (paddingValueInDp * getResources().getDisplayMetrics().density);
                            textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);


                            Button acceptButton = new Button(ViewPendingPatients.this);
                            acceptButton.setText("Accept");
                            Button rejectButton = new Button(ViewPendingPatients.this);
                            rejectButton.setText("Reject");


                            acceptButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    acceptPatient(patientSnapshot);
                                    containerLayout.removeView(patientLayout);
                                }
                            });

                            rejectButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    rejectPatient(patientSnapshot);
                                    containerLayout.removeView(patientLayout);
                                }
                            });

                            patientLayout.addView(textView);
                            patientLayout.addView(acceptButton);
                            patientLayout.addView(rejectButton);

                            containerLayout.addView(patientLayout);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void acceptPatient(DataSnapshot patientSnapshot) {
        try {
            // Get details
            String email = patientSnapshot.child("email").getValue(String.class);

            // new map for accepted patients
            Map<String, Object> acceptedPatient = new HashMap<>();
            acceptedPatient.put("email", email);
            acceptedPatient.put("firstName", patientSnapshot.child("firstName").getValue(String.class));
            acceptedPatient.put("lastName", patientSnapshot.child("lastName").getValue(String.class));
            acceptedPatient.put("address", patientSnapshot.child("address").getValue(String.class));
            acceptedPatient.put("phone", patientSnapshot.child("phone").getValue(String.class));
            acceptedPatient.put("healthCard", patientSnapshot.child("healthCard").getValue(String.class));
            acceptedPatient.put("status", "accepted"); // Set status to "accepted"

            // removes patient from patientRegRequests
            DatabaseReference patientRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("patientRegRequests")
                    .child(email.replace(".", ",")); // Firebase doesn't allow dots in keys
            patientRegRequestsRef.removeValue();

            // adds patient to acceptedPatients
            DatabaseReference acceptedPatientsRef = FirebaseDatabase.getInstance()
                    .getReference("accepted")
                    .child("acceptedPatients")
                    .child(email.replace(".", ",")); // Firebase doesn't allow dots in keys
            acceptedPatientsRef.setValue(acceptedPatient);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void rejectPatient(DataSnapshot patientSnapshot) {
        try {
            String email = patientSnapshot.child("email").getValue(String.class);

            // map for rejected patients
            Map<String, Object> rejectedPatient = new HashMap<>();
            rejectedPatient.put("email", email);
            rejectedPatient.put("firstName", patientSnapshot.child("firstName").getValue(String.class));
            rejectedPatient.put("lastName", patientSnapshot.child("lastName").getValue(String.class));
            rejectedPatient.put("address", patientSnapshot.child("address").getValue(String.class));
            rejectedPatient.put("phone", patientSnapshot.child("phone").getValue(String.class));
            rejectedPatient.put("healthCard", patientSnapshot.child("healthCard").getValue(String.class));
            rejectedPatient.put("status", "rejected"); // Set status to "rejected"

            // removess patients from patientRegRequests
            DatabaseReference patientRegRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("requests")
                    .child("patientRegRequests")
                    .child(email.replace(".", ",")); // Firebase doesn't allow dots in keys
            patientRegRequestsRef.removeValue();

            // adds patient to rejectedPatients
            DatabaseReference rejectedPatientsRef = FirebaseDatabase.getInstance()
                    .getReference("rejected")
                    .child("rejectedPatients")
                    .child(email.replace(".", ",")); // Firebase doesn't allow dots in keys
            rejectedPatientsRef.setValue(rejectedPatient);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void acceptAllClick(View view) {
        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("requests").child("patientRegRequests");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot patientSnapshot : dataSnapshot.getChildren()) {
                        acceptPatient(patientSnapshot);
                    }
                    LinearLayout containerLayout = findViewById(R.id.containerP);
                    containerLayout.removeAllViews();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void rejectAllClick(View view) {
        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("requests").child("patientRegRequests");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot patientSnapshot : dataSnapshot.getChildren()) {
                        rejectPatient(patientSnapshot);
                    }
                    LinearLayout containerLayout = findViewById(R.id.containerP);
                    containerLayout.removeAllViews();
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

