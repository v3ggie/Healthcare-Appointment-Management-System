package com.example.hams_test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.ArrayList;

public class RegistrationAdapter extends RecyclerView.Adapter<RegistrationAdapter.RegistrationViewHolder>  {

    private List<RegistrationData> registrationList;
    private ArrayList<RegistrationData> registrations;
    private Context context;

    private OnItemClickListener itemClickListener;
    private OnActionListener actionListener;

    public RegistrationAdapter(Context context, ArrayList<RegistrationData> registrations) {
        this.context = context;
        this.registrations = registrations;
    }

    public RegistrationAdapter() {
    }

    @NonNull
    @Override
    public RegistrationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.registration_adapter, parent, false);
        return new RegistrationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RegistrationViewHolder holder, int position) {
        RegistrationData registration = registrationList.get(holder.getAdapterPosition());

        holder.txtFirstName.setText("First Name: " + registration.getFirstName());
        holder.txtLastName.setText("Last Name: " + registration.getLastName());
        holder.txtEmail.setText("Email: " + registration.getEmail());
        holder.txtAddress.setText("Address: " + registration.getAddress());
        holder.txtPhoneNumber.setText("Phone Number: " + registration.getPhoneNumber());
        holder.txtCardOrEmployeeNumber.setText("Health Card/Employee Number: " + registration.getCardOrEmployeeNumber());

        if (registration.getDoctorSpecialty() != null && !registration.getDoctorSpecialty().isEmpty()) {
            holder.txtDoctorSpecialty.setVisibility(View.VISIBLE);
            holder.txtDoctorSpecialty.setText("Doctor Specialty: " + registration.getDoctorSpecialty());
        } else {
            holder.txtDoctorSpecialty.setVisibility(View.GONE);
        }

        // Implement the approve and decline actions
        holder.btnApprove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (actionListener != null) {
                    actionListener.onApprove(position);
                }
            }
        });

        holder.btnDecline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (actionListener != null) {
                    actionListener.onDecline(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return registrationList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public interface OnActionListener {
        void onApprove(int position);
        void onDecline(int position);
    }

    public void setItemClickListener(OnItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public void setActionListener(OnActionListener actionListener) {
        this.actionListener = actionListener;
    }

    public class RegistrationViewHolder extends RecyclerView.ViewHolder {
        TextView txtFirstName;
        TextView txtLastName;
        TextView txtEmail;
        TextView txtAddress;
        TextView txtPhoneNumber;
        TextView txtCardOrEmployeeNumber;
        TextView txtDoctorSpecialty;
        Button btnApprove;
        Button btnDecline;

        public RegistrationViewHolder(@NonNull View itemView) {
            super(itemView);
            txtFirstName = itemView.findViewById(R.id.txtFirstName);
            txtLastName = itemView.findViewById(R.id.txtLastName);
            txtEmail = itemView.findViewById(R.id.txtEmail);
            txtAddress = itemView.findViewById(R.id.txtAddress);
            txtPhoneNumber = itemView.findViewById(R.id.txtPhoneNumber);
            txtCardOrEmployeeNumber = itemView.findViewById(R.id.txtCardOrEmployeeNumber);
            txtDoctorSpecialty = itemView.findViewById(R.id.txtDoctorSpecialty);
            btnApprove = itemView.findViewById(R.id.btnApprove);
            btnDecline = itemView.findViewById(R.id.btnDecline);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (itemClickListener != null) {
                        itemClickListener.onItemClick(getAdapterPosition());
                    }
                }
            });
        }
    }

    public void setRegistrations                                                                                                                                                                                                                                                            (ArrayList<RegistrationData> registrations) {
        this.registrations = registrations;
        notifyDataSetChanged();
    }

    public RegistrationData getRegistration(int position) {
        if (position >= 0 && position < registrationList.size()) {
            return registrationList.get(position);
        }
        return  null;
    }

    public void updateStatus(int position, String newStatus) {
        if (position >= 0 && position < registrationList.size()) {
            RegistrationData registration = registrationList.get(position);
            registration.setStatus(newStatus);
            notifyItemChanged(position);
        }
    }
}
