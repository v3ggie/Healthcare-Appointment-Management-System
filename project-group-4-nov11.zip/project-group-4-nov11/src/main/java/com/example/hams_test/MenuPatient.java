package com.example.hams_test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MenuPatient extends AppCompatActivity {

    private TextView welcomeMessage;
    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_patient);

        welcomeMessage = findViewById(R.id.title);
        databaseReference = FirebaseDatabase.getInstance().getReference("requests");
        firebaseAuth = FirebaseAuth.getInstance();

        // Check if the user is logged in
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            // User is logged in, retrieve their email from the intent
            String userEmail = getIntent().getStringExtra("email");
            if (userEmail != null && !userEmail.isEmpty()) {
                // Retrieve the patient's name from the database
                retrievePatientName(userEmail);
            } else {
                Log.e("MenuPatient", "Email not found in the intent extras");
            }
        } else {
            Log.e("MenuPatient", "User is not logged in");
        }
    }

    private void retrievePatientName(String email) {
        // Replace '.' with ',' in the email to use as a key
        String key = encodeEmailAsKey(email);

        // Retrieve the patient's details from the database
        DatabaseReference patientsRef = databaseReference.child("patientRegRequests").child(key);
        patientsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Patient data found, update the welcome message
                    String firstName = dataSnapshot.child("firstName").getValue(String.class);
                    String lastName = dataSnapshot.child("lastName").getValue(String.class);
                    String patientName = firstName + " " + lastName;
                    updateWelcomeMessage(patientName);
                } else {
                    // If the data doesn't exist, log a message for debugging
                    Log.d("MenuPatient", "Data does not exist for key: " + key);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle database error
                Log.e("MenuPatient", "Error reading data: " + databaseError.getMessage());
            }
        });
    }

    private void updateWelcomeMessage(String patientName) {
        // Set the welcome message with the patient's name
        welcomeMessage.setText("Welcome, " + patientName + "!");
    }

    private String encodeEmailAsKey(String email) {
        return email.replace(".", ",");
    }
}
