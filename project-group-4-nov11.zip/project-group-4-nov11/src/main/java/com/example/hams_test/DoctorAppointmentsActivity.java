package com.example.hams_test;

import com.example.hams_test.Appointment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class DoctorAppointmentsActivity extends AppCompatActivity {
    private DatabaseReference databaseReference;
    private RecyclerView recyclerView;
    private DoctorAppointmentsAdapter appointmentsAdapter;
    private Doctor doctor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_appointments);

        doctor = (Doctor) getIntent().getSerializableExtra("doctor");

        databaseReference = FirebaseDatabase.getInstance().getReference("Doctor").child(doctor.getDoctorId()).child("appointments");
        recyclerView = findViewById(R.id.appointmentsRecyclerView);

        appointmentsAdapter = new DoctorAppointmentsAdapter(this, new ArrayList<>());

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(appointmentsAdapter);



        appointmentsAdapter.setItemClickListener(position -> {
            Appointment selectedAppointment = appointmentsAdapter.getAppointment(position);

            if (selectedAppointment != null && !selectedAppointment.isApproved()) {
                showAppointmentApprovalDialog(selectedAppointment);
            } else {
                viewPatientInformation(selectedAppointment);
            }
        });

        loadAppointmentsData();
    }

    private void loadAppointmentsData() {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ArrayList<Appointment> appointments = new ArrayList<>();
                ArrayList<Appointment> pastAppointments = new ArrayList<>();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Appointment appointment = snapshot.getValue(Appointment.class);
                    if (appointment != null) {
                        appointments.add(appointment);

                    }
                }
                doctor.setUpcomingAppointments(appointments);

                doctor.filterPastAppointments();

                appointmentsAdapter.setAppointments(doctor.getPastAppointments());
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(DoctorAppointmentsActivity.this, "Error loading data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });




        appointmentsAdapter.setActionListener(new DoctorAppointmentsAdapter.OnActionListener() {
            @Override
            public void onApprove(int position) {
                Appointment approvedAppointment = appointmentsAdapter.getAppointment(position);
                if (approvedAppointment != null && !approvedAppointment.isApproved()) {
                    // Implement your approval logic, for example:
                    approvedAppointment.approveAppointment();

                    // Save the updated appointment status to Firebase or your database
                    databaseReference.child(approvedAppointment.getAppointmentId()).setValue(approvedAppointment);

                    // Refresh the UI by loading the appointments data again
                    loadAppointmentsData();
                }
            }

            @Override
            public void onReject(int position) {
                Appointment rejectedAppointment = appointmentsAdapter.getAppointment(position);
                if (rejectedAppointment != null && !rejectedAppointment.isApproved()) {
                    // Implement your rejection logic, for example:
                    rejectedAppointment.rejectAppointment();

                    // Save the updated appointment status to Firebase or your database
                    databaseReference.child(rejectedAppointment.getAppointmentId()).setValue(rejectedAppointment);

                    // Refresh the UI by loading the appointments data again
                    loadAppointmentsData();
                }
            }

            @Override
            public void onCancel(int position) {
                Appointment canceledAppointment = appointmentsAdapter.getAppointment(position);
                if (canceledAppointment != null) {
                    cancelAppointment(canceledAppointment);
                }
            }
        });
    }

    private void showAppointmentApprovalDialog(Appointment appointment) {
        // Implement a dialog or any other UI element to allow the doctor to approve or reject the appointment
        // You may use AlertDialog or any other approach based on your UI requirements
        // Here, you can call the respective methods in the Doctor class to handle approval or rejection
        appointment.approveAppointment();
        // After approval or rejection, you may need to refresh the UI by loading the appointments data again
        loadAppointmentsData();
    }

    private void viewPatientInformation(Appointment appointment) {
        String patientId = appointment.getPatientId();
        getPatientNameFromId(patientId);
    }

    private void getPatientNameFromId(String patientId) {
        DatabaseReference patientRef = FirebaseDatabase.getInstance().getReference("Patients").child(patientId);

        patientRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String patientName = dataSnapshot.child("patientName").getValue(String.class);

                if (patientName != null) {
                    Toast.makeText(DoctorAppointmentsActivity.this, "Patient Name: " + patientName, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(DoctorAppointmentsActivity.this, "Error loading patient data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onBackToWelcomeClick(View view) {
        Intent intent = new Intent(DoctorAppointmentsActivity.this, WelcomeActivityDoctor.class);
        startActivity(intent);
    }

    // Method to handle automatic approval of all appointments
    public void onAutoApproveAllClick(View view) {
        // Implement the logic to automatically approve all pending appointments
        doctor.approveAllAppointmentsAutomatically();
        // After auto-approval, you may need to refresh the UI by loading the appointments data again
        loadAppointmentsData();
    }

    private void cancelAppointment(Appointment appointment) {
        if (appointment.isApproved()) {
            // Implement logic to cancel the appointment, for example:
            appointment.setApproved(false);
            // Save the updated appointment status to Firebase or your database
            databaseReference.child(appointment.getAppointmentId()).setValue(appointment);
            // Refresh the UI by loading the appointments data again
            loadAppointmentsData();
        } else {
            Toast.makeText(this, "Cannot cancel an unapproved appointment.", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to handle adding a new appointment
    public void onScheduleAppointmentClick(View view) {
        // You may need to collect information for the new appointment from the user
        // For simplicity, I'll create a dummy appointment here
        Appointment newAppointment = new Appointment("456", "New Patient", "2023-11-16", "2:30 PM", false, "789",  "101");

        // Get a reference to the "appointments" node in the doctor's section of the database
        String doctorId = "yourDoctorId"; // Replace with the actual doctor's ID
        DatabaseReference appointmentsRef = FirebaseDatabase.getInstance().getReference("Doctor").child(doctorId).child("appointments");

        // Push a new child node for the appointment
        String appointmentKey = appointmentsRef.push().getKey();

        // Set the appointment data under the generated key
        appointmentsRef.child(appointmentKey).setValue(newAppointment);

        // Now, the new appointment data is added to the Firebase Realtime Database
    }






}