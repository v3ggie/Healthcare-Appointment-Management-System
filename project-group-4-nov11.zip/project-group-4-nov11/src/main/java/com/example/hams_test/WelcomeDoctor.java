package com.example.hams_test;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeDoctor extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_doctor);
        TextView welcomeMessage = findViewById(R.id.welcomeMessage);
        String role = getIntent().getStringExtra("role");
        String userEmail = getIntent().getStringExtra("email");
        welcomeMessage.setText("Welcome Doctor! You are logged in.");
    }

    public void onNextClick(View view) {
        Intent intent = new Intent(WelcomeDoctor.this, MenuDoctor.class);
        String userEmail = getIntent().getStringExtra("email");
        startActivity(intent);
    }
    public void onLogoutClick(View view) {
        Intent intent = new Intent(WelcomeDoctor.this, RoleSelectionActivity.class);
        startActivity(intent);
    }

}
