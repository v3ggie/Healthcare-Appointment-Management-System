package com.example.hams_test;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RegistrationDetailActivity extends AppCompatActivity {
    private RegistrationData registration;
    private int adapterPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_detail);

        // Retrieve the registration data passed from AdminMenuActivity
        Intent intent = getIntent();
        RegistrationData registration = intent.getParcelableExtra("registrationData");
        int adapterPosition = intent.getIntExtra("adapterPosition", -1);

        if (registration != null) {
            // Display the registration details
            TextView txtFirstName = findViewById(R.id.txtFirstName);
            TextView txtLastName = findViewById(R.id.txtLastName);
            TextView txtEmail = findViewById(R.id.txtEmail);
            TextView txtAddress = findViewById(R.id.txtAddress);
            TextView txtPhoneNumber = findViewById(R.id.txtPhoneNumber);
            TextView txtCardOrEmployeeNumber = findViewById(R.id.txtCardOrEmployeeNumber);
            TextView txtDoctorSpecialty = findViewById(R.id.txtDoctorSpecialty);

            txtFirstName.setText("First Name: " + registration.getFirstName());
            txtLastName.setText("Last Name: " + registration.getLastName());
            txtEmail.setText("Email: " + registration.getEmail());
            txtAddress.setText("Address: " + registration.getAddress());
            txtPhoneNumber.setText("Phone Number: " + registration.getPhoneNumber());
            txtCardOrEmployeeNumber.setText("Health Card or Employee Number: " + registration.getCardOrEmployeeNumber());

            if (registration.getDoctorSpecialty() != null && !registration.getDoctorSpecialty().isEmpty()) {
                txtDoctorSpecialty.setText("Doctor Specialty: " + registration.getDoctorSpecialty());
            } else {
                // Hide the doctor specialty field if it's empty
                txtDoctorSpecialty.setVisibility(View.GONE);
            }
        }

        Button btnApprove = findViewById(R.id.btnApprove);
        btnApprove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference registrationRef = FirebaseDatabase.getInstance().getReference("requests").child(registration.getId());
                registrationRef.child("status").setValue("Approved", new DatabaseReference.CompletionListener() {
                    @Override
                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                        if (databaseError == null) {
                            Toast.makeText(RegistrationDetailActivity.this, "Registration Approved", Toast.LENGTH_SHORT).show();
                            onApprove(adapterPosition);
                        } else {
                            Toast.makeText(RegistrationDetailActivity.this, "Approval failed: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        Button btnDecline = findViewById(R.id.btnDecline);
        btnDecline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference registrationRef = FirebaseDatabase.getInstance().getReference("requests").child(registration.getId());
                registrationRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            String status = dataSnapshot.child("status").getValue(String.class);
                            if (status != null && !status.equals("Approved")) {
                                registrationRef.child("status").setValue("Declined", new DatabaseReference.CompletionListener() {
                                    @Override
                                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                                        if (databaseError == null) {
                                            Toast.makeText(RegistrationDetailActivity.this, "Registration Declined", Toast.LENGTH_SHORT).show();
                                            onDecline(adapterPosition);
                                        } else {
                                            Toast.makeText(RegistrationDetailActivity.this, "Decline failed: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                            } else {
                                Toast.makeText(RegistrationDetailActivity.this, "This registration has already been approved and cannot be declined", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        // Handle Error
                        Toast.makeText(RegistrationDetailActivity.this, "Error loading data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
        public void onApprove(int position) {
            // Update the status to Approved in Firebase database
            DatabaseReference registrationRef = FirebaseDatabase.getInstance().getReference("requests").child(registration.getId());
            registrationRef.child("status").setValue("Approved", new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                    if (databaseError == null) {
                        Toast.makeText(RegistrationDetailActivity.this, "Registration Approved", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(RegistrationDetailActivity.this, "Approval failed: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        public void onDecline(int position) {
            // Update the status to Declined in Firebase database
            DatabaseReference registrationRef = FirebaseDatabase.getInstance().getReference("requests").child(registration.getId());
            registrationRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        String status = dataSnapshot.child("status").getValue(String.class);
                        if (status != null && !status.equals("Approved")) {
                            registrationRef.child("status").setValue("Declined", new DatabaseReference.CompletionListener() {
                                @Override
                                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                                    if (databaseError == null) {
                                        Toast.makeText(RegistrationDetailActivity.this, "Registration Declined", Toast.LENGTH_SHORT).show();
                                        finish(); // Close the activity
                                    } else {
                                        Toast.makeText(RegistrationDetailActivity.this, "Decline failed: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        } else {
                            Toast.makeText(RegistrationDetailActivity.this, "This registration has already been approved and cannot be declined", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                @Override
                public void onCancelled(DatabaseError error) {
                    // Handle Error
                    Toast.makeText(RegistrationDetailActivity.this, "Error loading data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
