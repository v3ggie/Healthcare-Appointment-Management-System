package com.example.hams_test;

import java.util.Calendar;

public class Shift {
    private String startTime;
    private String endTime;
    private int day;
    private int month;
    private String employeeNumber;


    public Shift(String startTime, String endTime, int day, int month, String employeeNumber) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.day = day;
        this.month = month;
        this.employeeNumber = employeeNumber;
    }



    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }


}
