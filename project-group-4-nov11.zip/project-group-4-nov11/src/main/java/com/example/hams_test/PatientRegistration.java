package com.example.hams_test;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PatientRegistration extends AppCompatActivity {

    private EditText firstNameEditText;
    private EditText lastNameEditText;
    private EditText emailEditText;
    private EditText passwordEditText;
    private EditText phoneEditText;
    private EditText addressEditText;
    private EditText healthCardEditText;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_patient);

        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        addressEditText = findViewById(R.id.addressEditText);
        healthCardEditText = findViewById(R.id.healthCardEditText);

        databaseReference = FirebaseDatabase.getInstance().getReference("requests");
    }

    public void onDoneClick(View view) {
        if (validateFields()) {
            Patient patient = new Patient(
                    firstNameEditText.getText().toString(),
                    lastNameEditText.getText().toString(),
                    emailEditText.getText().toString(),
                    passwordEditText.getText().toString(),
                    phoneEditText.getText().toString(),
                    addressEditText.getText().toString(),
                    healthCardEditText.getText().toString(),
                    "Pending");

            // Generate a unique key for the patient
            String key = encodeNameAsKey(patient.getFirstName(), patient.getLastName());

            // Set the key in the patient object
            patient.setKey(key);

            DatabaseReference patientsRef = databaseReference.child("patientRegRequests").child(key);


            patientsRef.child("status").setValue(patient.getStatus());
            patientsRef.child("firstName").setValue(patient.getFirstName());
            patientsRef.child("lastName").setValue(patient.getLastName());
            patientsRef.child("email").setValue(patient.getEmail());
            patientsRef.child("password").setValue(patient.getPassword());
            patientsRef.child("phone").setValue(patient.getPhone());
            patientsRef.child("address").setValue(patient.getAddress());
            patientsRef.child("healthCard").setValue(patient.getHealthCard());

            Intent intent = new Intent(this, PendingRegistration.class);
            startActivity(intent);
            finish();
        }
    }

    private String encodeEmailAsKey(String email) {
        return email.replace(".", ",");
    }

    private String encodeNameAsKey(String firstName, String lastName) {
        return firstName + " " + lastName;
    }


    private boolean validateFirstName(EditText editText, String fieldName) {
        String fieldValue = editText.getText().toString().trim();
        if (fieldValue.isEmpty()) {
            editText.setError(fieldName + " cannot be empty");
            return false;
        } else if (!fieldValue.matches("^[a-zA-Z]+$")) {
            editText.setError(fieldName + " must contain only letters");
            return false;
        }
        editText.setError(null);
        return true;
    }

    private boolean validateLastName(EditText editText, String fieldName) {
        String fieldValue = editText.getText().toString().trim();
        if (fieldValue.isEmpty()) {
            editText.setError(fieldName + " cannot be empty");
            return false;
        } else if (!fieldValue.matches("^[a-zA-Z]+$")) {
            editText.setError(fieldName + " must contain only letters");
            return false;
        }
        editText.setError(null);
        return true;
    }

    private boolean validateFields() {
        return validateFirstName(firstNameEditText, "First Name") &&
                validateLastName(lastNameEditText, "Last Name") &&
                validateEmail(emailEditText) &&
                validatePassword(passwordEditText) &&
                validatePhoneNumber(phoneEditText) &&
                validateField(addressEditText, "Address") &&
                validateHealthCardNumber(healthCardEditText);
    }


    private boolean validateField(EditText editText, String fieldName) {
        String fieldValue = editText.getText().toString().trim();
        if (fieldValue.isEmpty()) {
            editText.setError(fieldName + " cannot be empty");
            return false;
        }
        editText.setError(null);
        return true;
    }

    private boolean validateEmail(EditText emailEditText) {
        String email = emailEditText.getText().toString().trim();
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.setError("Enter a valid email address");
            return false;
        }
        emailEditText.setError(null);
        return true;
    }

    private boolean validatePassword(EditText passwordEditText) {
        String password = passwordEditText.getText().toString().trim();
        if (password.isEmpty() || !password.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,}$")) {
            passwordEditText.setError("Password must contain at least 1 digit, 1 lowercase, 1 uppercase letter, and be at least 6 characters long.");
            return false;
        }
        passwordEditText.setError(null);
        return true;
    }

    private boolean validatePhoneNumber(EditText phoneEditText) {
        String phoneNumber = phoneEditText.getText().toString().trim();
        if (phoneNumber.isEmpty() || !phoneNumber.matches("^[0-9]+$")) {
            phoneEditText.setError("Enter a valid phone number");
            return false;
        }
        phoneEditText.setError(null);
        return true;
    }

    private boolean validateHealthCardNumber(EditText healthCardEditText) {
        String healthCardNumber = healthCardEditText.getText().toString().trim();
        if (healthCardNumber.isEmpty() || !healthCardNumber.matches("^[0-9]+$")) {
            healthCardEditText.setError("Enter a valid health card number");
            return false;
        }
        healthCardEditText.setError(null);
        return true;
    }


}
