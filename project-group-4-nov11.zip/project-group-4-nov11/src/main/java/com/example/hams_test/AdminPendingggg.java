package com.example.hams_test;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AdminPendingggg extends AppCompatActivity {
    private DatabaseReference databaseReference;
    private RecyclerView recyclerView;
    private RegistrationAdapter registrationAdapter;

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.admin_pending);

        databaseReference = FirebaseDatabase.getInstance().getReference("requests");
        recyclerView = findViewById(R.id.recyclerView);

        registrationAdapter = new RegistrationAdapter(this, new ArrayList<RegistrationData>());

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(registrationAdapter);

        registrationAdapter.setItemClickListener(new RegistrationAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                RegistrationData registration = registrationAdapter.getRegistration(position);
                if (registration != null) {
                    String registrationId = registration.getId();

                    Intent intent = new Intent(AdminPendingggg.this, RegistrationDetailActivity.class);
                    intent.putExtra("registrationId", registrationId);
                    intent.putExtra("adapterPosition",position);
                    intent.putExtra("registrationData",registration);
                    startActivity(intent);
                }
            }
        });
        loadPendingRegistrationData();
    }

    private void loadPendingRegistrationData() {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ArrayList<RegistrationData> pendingRegistrations = new ArrayList<>();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    RegistrationData registration = snapshot.getValue(RegistrationData.class);
                    if (registration != null && "Pending".equals(registration.getStatus())) {
                        pendingRegistrations.add(registration);
                    }
                }
                registrationAdapter.setRegistrations(pendingRegistrations);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(AdminPendingggg.this, "Error loading data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
