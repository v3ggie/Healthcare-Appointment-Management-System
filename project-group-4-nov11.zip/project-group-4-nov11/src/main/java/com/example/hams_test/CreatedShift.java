package com.example.hams_test;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class CreatedShift extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_shift);
    }

    // THIS IS JUST A SCREEN TO CONFIRM SHIFT CREATION, IGNORE.

}
