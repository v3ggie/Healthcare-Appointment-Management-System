package com.example.hams_test;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomePatient extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_patient);
        TextView welcomeMessage = findViewById(R.id.welcomeMessage);
        String role = getIntent().getStringExtra("role");
        welcomeMessage.setText("Welcome! You are now logged in.");
    }

    public void onNextClick(View view) {
        Intent intent = new Intent(WelcomePatient.this, MenuPatient.class);
        startActivity(intent);
    }
    public void onLogoutClick(View view) {
        Intent intent = new Intent(WelcomePatient.this, RoleSelectionActivity.class);
        startActivity(intent);
    }

}
