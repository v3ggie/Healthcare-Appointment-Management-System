package com.example.hams_test;

import android.os.Parcel;
import android.os.Parcelable;
public class RegistrationData  extends android.app.Activity implements Parcelable {
    private String id;
    private String firstName;
    private String lastName;
    private String email;
    private String address;
    private String phoneNumber;
    private String cardOrEmployeeNumber;
    private String doctorSpecialty;
    private String status;

    public RegistrationData() {
        // Default constructor required for Firebase to work with this class.
    }

    public RegistrationData(String id, String firstName, String lastName, String email, String address, String phoneNumber, String cardOrEmployeeNumber, String doctorSpecialty, String status) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.cardOrEmployeeNumber = cardOrEmployeeNumber;
        this.doctorSpecialty = doctorSpecialty;
        this.status = status;
    }

    // Getters and setters for each field
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCardOrEmployeeNumber() {
        return cardOrEmployeeNumber;
    }

    public void setCardOrEmployeeNumber(String cardOrEmployeeNumber) {
        this.cardOrEmployeeNumber = cardOrEmployeeNumber;
    }

    public String getDoctorSpecialty() {
        return doctorSpecialty;
    }

    public void setDoctorSpecialty(String doctorSpecialty) {
        this.doctorSpecialty = doctorSpecialty;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    protected RegistrationData(Parcel in) {
        // Read data from Parcel and set values for your fields
    }

    public static final Creator<RegistrationData> CREATOR = new Creator<RegistrationData>() {
        @Override
        public RegistrationData createFromParcel(Parcel in) {
            return new RegistrationData(in);
        }

        @Override
        public RegistrationData[] newArray(int size) {
            return new RegistrationData[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        // Write data to Parcel for each field
    }

    @Override
    public int describeContents() {
        return 0;
    }
}

