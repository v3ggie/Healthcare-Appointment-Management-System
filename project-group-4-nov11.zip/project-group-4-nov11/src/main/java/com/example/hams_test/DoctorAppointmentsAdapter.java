package com.example.hams_test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
public class DoctorAppointmentsAdapter extends RecyclerView.Adapter<DoctorAppointmentsAdapter.AppointmentViewHolder> {

    private List<Appointment> appointments;
    private Context context;

    private OnItemClickListener itemClickListener;
    private OnActionListener actionListener;

    public DoctorAppointmentsAdapter(Context context, List<Appointment> appointments) {
        this.context = context;
        this.appointments = appointments;
    }

    @NonNull
    @Override
    public AppointmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.appointment_adapter, parent, false);
        return new AppointmentViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull AppointmentViewHolder holder, int position) {
        Appointment appointment = appointments.get(position);

        // Populate the views with appointment information
        holder.txtPatientName.setText("Patient: " + appointment.getPatientName());
        holder.txtDate.setText("Date: " + appointment.getDate());
        holder.txtTime.setText("Time: " + appointment.getTime());
        holder.txtStatus.setText("Status: " + (appointment.isApproved() ? "Approved" : "Pending"));

        // Implement the approve, reject, and view actions
        holder.btnApprove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (actionListener != null) {
                    actionListener.onApprove(position);
                }
            }
        });

        holder.btnReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (actionListener != null) {
                    actionListener.onReject(position);
                }
            }
        });

        holder.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (actionListener != null) {
                    actionListener.onCancel(position);
                }
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (itemClickListener != null) {
                    itemClickListener.onItemClick(position);
                }
            }
        });
    }




    @Override
    public int getItemCount() {
        return appointments.size();
    }

    public void setItemClickListener(OnItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public interface OnActionListener {
        void onApprove(int position);

        void onReject(int position);
        void onCancel(int position);
    }

    public class AppointmentViewHolder extends RecyclerView.ViewHolder {
        TextView txtPatientName;
        TextView txtDate;
        TextView txtTime;
        TextView txtStatus;
        Button btnApprove;
        Button btnReject;
        Button btnCancel;

        public AppointmentViewHolder(@NonNull View itemView) {
            super(itemView);
            txtPatientName = itemView.findViewById(R.id.txtPatientName);
            txtDate = itemView.findViewById(R.id.txtDate);
            txtTime = itemView.findViewById(R.id.txtTime);
            txtStatus = itemView.findViewById(R.id.txtStatus);
            btnApprove = itemView.findViewById(R.id.btnApprove);
            btnReject = itemView.findViewById(R.id.btnReject);
            btnCancel = itemView.findViewById(R.id.btnCancel);
        }
    }


    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
        notifyDataSetChanged();
    }

    public Appointment getAppointment(int position) {
        if (position >= 0 && position < appointments.size()) {
            return appointments.get(position);
        }
        return null;
    }
    public void setActionListener(OnActionListener actionListener) {
        this.actionListener = actionListener;
    }








}