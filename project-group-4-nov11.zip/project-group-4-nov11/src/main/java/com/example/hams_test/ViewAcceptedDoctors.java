package com.example.hams_test;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ViewAcceptedDoctors extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_accepted_doctors);
        LinearLayout containerLayout = findViewById(R.id.containerP);

        try {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("accepted").child("acceptedDoctors");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot doctorSnapshot : dataSnapshot.getChildren()) {
                        String firstName = doctorSnapshot.child("firstName").getValue(String.class);
                        String lastName = doctorSnapshot.child("lastName").getValue(String.class);
                        String email = doctorSnapshot.child("email").getValue(String.class);
                        String phone = doctorSnapshot.child("phone").getValue(String.class);
                        String status = doctorSnapshot.child("status").getValue(String.class);

                        if (firstName != null && lastName != null && email != null && phone != null && status != null) {
                            TextView textView = new TextView(ViewAcceptedDoctors.this);
                            textView.setText(String.format("Name: %s %s\nEmail: %s\nPhone: %s\nStatus: %s",
                                    firstName, lastName, email, phone, status));
                            textView.setTextColor(getResources().getColor(android.R.color.white));
                            textView.setBackgroundResource(R.drawable.textview_background);
                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT
                            );
                            layoutParams.setMargins(0, 0, 0, 16);
                            textView.setLayoutParams(layoutParams);
                            int paddingValueInDp = 14;
                            int paddingValueInPixels = (int) (paddingValueInDp * getResources().getDisplayMetrics().density);
                            textView.setPadding(paddingValueInPixels, paddingValueInPixels, paddingValueInPixels, paddingValueInPixels);

                            containerLayout.addView(textView);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
