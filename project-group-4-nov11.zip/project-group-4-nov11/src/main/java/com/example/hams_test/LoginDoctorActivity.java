package com.example.hams_test;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginDoctorActivity extends AppCompatActivity {

    private EditText emailEditText;
    private EditText passwordEditText;
    private Button logInButton;
    private Button signUpButton;
    private View loginLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_doctor);

        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        logInButton = findViewById(R.id.loginButton);
        signUpButton = findViewById(R.id.signUpButton);

        String role = getIntent().getStringExtra("role");

        TextView loginTitle = findViewById(R.id.loginTitle);
        loginTitle.setText(role + " Login");

        loginLayout = findViewById(R.id.loginLayout);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String role = getIntent().getStringExtra("role");
                Intent intent = new Intent(LoginDoctorActivity.this, DoctorRegistration.class);
                startActivity(intent);
            }
        });

        logInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String role = getIntent().getStringExtra("role");
                if (validateFields()) {
                    String userEmail = emailEditText.getText().toString().trim();
                    Intent welcomeIntent = new Intent(LoginDoctorActivity.this, WelcomeDoctor.class);
                    welcomeIntent.putExtra("email", userEmail);
                    startActivity(welcomeIntent);
                }
            }
        });
    }

    private boolean validateFields() {
        boolean isValid = true;
        if (emailEditText.getText().toString().trim().isEmpty()) {
            emailEditText.setError("Email cannot be empty");
            isValid = false;
        } else {
            emailEditText.setError(null);
        }
        if (passwordEditText.getText().toString().trim().isEmpty()) {
            passwordEditText.setError("Password cannot be empty");
            isValid = false;
        } else {
            passwordEditText.setError(null);
        }
        return isValid;
    }
}
