package com.example.hams_test;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MenuAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.menu_admin);
    }

    public void onPendingClick(View view) {
        Intent intent = new Intent(MenuAdmin.this, MenuAdminPendingSelection.class);
        startActivity(intent);
    }

    public void onAcceptedClick(View view) {
        Intent intent = new Intent(MenuAdmin.this, MenuAdminAcceptedSelection.class);
        startActivity(intent);
    }

    public void onRejectedClick(View view) {
        Intent intent = new Intent(MenuAdmin.this, MenuAdminRejectedSelection.class);
        startActivity(intent);
    }

}
