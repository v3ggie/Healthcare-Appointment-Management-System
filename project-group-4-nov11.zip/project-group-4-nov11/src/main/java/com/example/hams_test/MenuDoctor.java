package com.example.hams_test;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MenuDoctor extends AppCompatActivity {

    private TextView welcomeMessage;
    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_doctor);

        welcomeMessage = findViewById(R.id.title);
        databaseReference = FirebaseDatabase.getInstance().getReference("accepted");
        firebaseAuth = FirebaseAuth.getInstance();

        // Check if the user is logged in
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            // Retrieve the email from the intent
            String userEmail = getIntent().getStringExtra("email");
            if (userEmail != null && !userEmail.isEmpty()) {
                // Retrieve additional information or perform actions with the email
                retrieveDoctorName(userEmail);
            } else {
                Log.e("MenuDoctor", "Email not found in the intent extras");
            }
        } else {
            Log.e("MenuDoctor", "User is not logged in");
        }
    }


    private void retrieveDoctorName(String email) {
        String key = encodeEmailAsKey(email);

        // Retrieve the patient's details from the database
        DatabaseReference doctorsRef = databaseReference.child("doctorRegRequests").child(key);
        doctorsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String firstName = dataSnapshot.child("firstName").getValue(String.class);
                    String lastName = dataSnapshot.child("lastName").getValue(String.class);
                    String DoctorName = firstName + " " + lastName;
                    updateWelcomeMessage(DoctorName);
                } else {
                    Log.d("MenuDoctor", "Data does not exist for key: " + key);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("MenuDoctor", "Error reading data: " + databaseError.getMessage());
            }
        });
    }

    private void updateWelcomeMessage(String patientName) {
        welcomeMessage.setText("Welcome, Doctor");
    }

    private String encodeEmailAsKey(String email) {
        return email.replace(".", ",");
    }

    public void goShiftClick(View view) {
        Intent intent = new Intent(MenuDoctor.this, ShiftCreate.class);
        String userEmail = getIntent().getStringExtra("email");
        startActivity(intent);
        finish();
    }

    public void viewShifts(View view) {
        Intent intent = new Intent(MenuDoctor.this, SearchShiftsActivity.class);
        startActivity(intent);
    }


}
